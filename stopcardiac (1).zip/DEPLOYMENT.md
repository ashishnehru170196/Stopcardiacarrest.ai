# StopCardiac Deployment & QA Due Diligence

This document outlines the infrastructure, security, and compliance setup for the StopCardiac platform, specifically for deployment on **Netlify** (Frontend) and **Supabase** (Backend).

## 1. Infrastructure Setup

### Frontend (Netlify)
- **Build Command**: `npm run build`
- **Publish Directory**: `dist`
- **SPA Routing**: Configured via `netlify.toml` to redirect all traffic to `index.html`.
- **Environment Variables**: Ensure `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are set in the Netlify dashboard.

### Backend (Supabase)
- **Database**: PostgreSQL-based database for Profiles, Orders, and Reports.
- **Authentication**: Supabase Auth handles secure sign-in/sign-up.
- **Storage**: (Optional) Can be used for storing raw genetic data files if needed.

## 2. Security & Compliance

### Data Privacy (HIPAA Readiness)
- **Row Level Security (RLS)**: **CRITICAL.** You must enable RLS on all tables in Supabase.
  - `profiles`: Users can only read/update their own profile.
  - `orders`: Users can only read their own orders.
  - `reports`: Users can only read reports linked to their own orders.
- **Encryption**: Data is encrypted at rest and in transit (via SSL/TLS).
- **Audit Logs**: Supabase provides logs for authentication and database operations.

### API Security
- **Anon Key**: The `VITE_SUPABASE_ANON_KEY` is safe for client-side use when combined with RLS.
- **Service Role Key**: **NEVER** expose the `service_role` key in the frontend.

## 3. Database Schema (Required Setup)

Run the following SQL in your Supabase SQL Editor:

```sql
-- Profiles table (linked to Auth)
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  name text,
  role text default 'user' check (role in ('user', 'admin')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Orders table
create table orders (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade not null,
  status text default 'ordered' check (status in ('ordered', 'shipped', 'sample_registered', 'sample_received', 'in_lab', 'report_ready')),
  shipping_address text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Reports table
create table reports (
  id uuid default gen_random_uuid() primary key,
  order_id uuid references orders(id) on delete cascade not null,
  result text check (result in ('normal', 'vus', 'likely_pathogenic', 'pathogenic')),
  explanation text,
  physician_name text,
  physician_license text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS
alter table profiles enable row level security;
alter table orders enable row level security;
alter table reports enable row level security;

-- Example Policy: Users can see their own profile
create policy "Users can view own profile" on profiles for select using (auth.uid() = id);
```

## 4. Operational Checklist
- [ ] Verify Supabase RLS policies are active.
- [ ] Set up Netlify environment variables.
- [ ] Test the Auth flow (Sign up -> Login -> Dashboard).
- [ ] Verify the "Order Test" flow creates a record in Supabase.
- [ ] Ensure Gemini API key is configured in the environment.

## 5. QA Verification
- **End-to-End Logic**: The frontend now communicates directly with Supabase, removing the need for a custom Express server and simplifying the architecture for Netlify.
- **Error Handling**: Supabase client handles network errors and auth failures gracefully.
- **Performance**: Vite build ensures a highly optimized frontend bundle.

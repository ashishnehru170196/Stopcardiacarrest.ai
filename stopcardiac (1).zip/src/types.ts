export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
}

export interface Order {
  id: string;
  user_id: string;
  status: 'ordered' | 'shipped' | 'sample_registered' | 'sample_received' | 'in_lab' | 'report_ready';
  shipping_address: string;
  created_at: string;
  user_email?: string;
  user_name?: string;
}

export interface Report {
  id: string;
  order_id: string;
  result: 'normal' | 'vus' | 'likely_pathogenic' | 'pathogenic';
  explanation: string;
  physician_name: string;
  physician_license: string;
  created_at: string;
}

export type ResultType = 'normal' | 'vus' | 'likely_pathogenic' | 'pathogenic';

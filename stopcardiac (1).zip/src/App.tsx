import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Shield, 
  Activity, 
  ArrowRight, 
  CheckCircle2, 
  Package, 
  Clock, 
  FileText, 
  User, 
  Menu, 
  X,
  MessageSquare,
  ChevronRight,
  AlertTriangle,
  Search,
  Stethoscope,
  Info,
  Download,
  LogOut,
  ChevronDown,
  Dna,
  ShieldCheck,
  ShoppingBag,
  Star,
  Zap,
  Flame,
  Smartphone,
  Watch,
  Bell,
  Calendar,
  RefreshCw,
  HeartPulse,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Loader2
} from 'lucide-react';
import { User as UserType, Order, Report, ResultType } from './types';
import { getChatResponse, interpretReport, evaluateRisk, generateTechnicalExplanation, connectLiveAudio } from './services/geminiService';
import { supabase } from './services/supabase';
import { Modality, LiveServerMessage } from "@google/genai";

// --- Components ---

const DNABackground = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none -z-10 opacity-[0.08]">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1px] h-full bg-gradient-to-b from-transparent via-[#0071e3]/20 to-transparent" />
      <svg className="w-full h-full" viewBox="0 0 800 1200" preserveAspectRatio="xMidYMid slice">
        {[...Array(30)].map((_, i) => {
          const delay = i * 0.15;
          const duration = 10;
          return (
            <motion.g key={i}>
              <motion.circle
                r="2.5"
                fill="#0071e3"
                initial={{ cx: 400, cy: -100 }}
                animate={{
                  cx: [370, 430, 370],
                  cy: [-100, 1300],
                }}
                transition={{
                  cx: { duration: 3.5, repeat: Infinity, ease: "easeInOut", delay },
                  cy: { duration, repeat: Infinity, ease: "linear", delay: -i * (duration/30) }
                }}
              />
              <motion.circle
                r="2.5"
                fill="#10b981"
                initial={{ cx: 400, cy: -100 }}
                animate={{
                  cx: [430, 370, 430],
                  cy: [-100, 1300],
                }}
                transition={{
                  cx: { duration: 3.5, repeat: Infinity, ease: "easeInOut", delay },
                  cy: { duration, repeat: Infinity, ease: "linear", delay: -i * (duration/30) }
                }}
              />
              <motion.line
                stroke="#000"
                strokeWidth="0.3"
                strokeOpacity="0.2"
                initial={{ y1: -100, y2: -100 }}
                animate={{
                  x1: [370, 430, 370],
                  x2: [430, 370, 430],
                  y1: [-100, 1300],
                  y2: [-100, 1300],
                }}
                transition={{
                  x1: { duration: 3.5, repeat: Infinity, ease: "easeInOut", delay },
                  x2: { duration: 3.5, repeat: Infinity, ease: "easeInOut", delay },
                  y1: { duration, repeat: Infinity, ease: "linear", delay: -i * (duration/30) },
                  y2: { duration, repeat: Infinity, ease: "linear", delay: -i * (duration/30) }
                }}
              />
            </motion.g>
          );
        })}
      </svg>
    </div>
  );
};

const DNAVisual = () => {
  return (
    <div className="relative w-full h-[500px] flex items-center justify-center">
      <div className="absolute inset-0 bg-blue-500/5 rounded-[2rem] border border-blue-500/20 backdrop-blur-sm" />
      <svg className="w-full h-full p-12" viewBox="0 0 200 400">
        {[...Array(15)].map((_, i) => {
          const delay = i * 0.3;
          return (
            <motion.g key={i}>
              <motion.circle
                r="4"
                fill="#0071e3"
                animate={{
                  cx: [70, 130, 70],
                  cy: [i * 25 + 25],
                }}
                transition={{
                  cx: { duration: 3, repeat: Infinity, ease: "easeInOut", delay },
                }}
              />
              <motion.circle
                r="4"
                fill="#10b981"
                animate={{
                  cx: [130, 70, 130],
                  cy: [i * 25 + 25],
                }}
                transition={{
                  cx: { duration: 3, repeat: Infinity, ease: "easeInOut", delay },
                }}
              />
              <motion.line
                stroke="#0071e3"
                strokeWidth="1"
                strokeOpacity="0.3"
                animate={{
                  x1: [70, 130, 70],
                  x2: [130, 70, 130],
                  y1: [i * 25 + 25],
                  y2: [i * 25 + 25],
                }}
                transition={{
                  x1: { duration: 3, repeat: Infinity, ease: "easeInOut", delay },
                  x2: { duration: 3, repeat: Infinity, ease: "easeInOut", delay },
                }}
              />
            </motion.g>
          );
        })}
      </svg>
    </div>
  );
};

const Navbar = ({ user, onLogout, onNavigate }: { user: UserType | null, onLogout: () => void, onNavigate: (page: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-nav">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center cursor-pointer group" onClick={() => onNavigate('home')}>
            <div className="relative">
              <Dna className="h-7 w-7 text-[#0071e3] transition-transform group-hover:rotate-12" />
              <Heart className="absolute -bottom-1 -right-1 h-4 w-4 text-brand-accent fill-brand-accent/20" />
            </div>
            <div className="ml-2.5 flex flex-col">
              <span className="text-lg font-display font-bold tracking-tight text-brand-primary">StopCardiac</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={() => onNavigate('how-it-works')} className="text-[#1d1d1f]/70 hover:text-[#1d1d1f] font-medium text-[13px] transition-colors">How It Works</button>
            <button onClick={() => onNavigate('science')} className="text-[#1d1d1f]/70 hover:text-[#1d1d1f] font-medium text-[13px] transition-colors">Science</button>
            <button onClick={() => onNavigate('shop')} className="text-[#1d1d1f]/70 hover:text-[#1d1d1f] font-medium text-[13px] transition-colors">Shop</button>
            <button onClick={() => onNavigate('sync')} className="text-[#1d1d1f]/70 hover:text-[#1d1d1f] font-medium text-[13px] transition-colors">Health Sync</button>
            <button onClick={() => onNavigate('faq')} className="text-[#1d1d1f]/70 hover:text-[#1d1d1f] font-medium text-[13px] transition-colors">FAQ</button>
            {user ? (
              <div className="flex items-center space-x-6">
                <button onClick={() => onNavigate('dashboard')} className="bg-[#1d1d1f] text-white px-5 py-2 rounded-full text-[13px] font-semibold hover:bg-[#323234] transition-all">
                  Dashboard
                </button>
                <button onClick={() => onNavigate('profile')} className="text-[#1d1d1f]/40 hover:text-[#1d1d1f] transition-colors">
                  <User className="w-4 h-4" />
                </button>
                <button onClick={onLogout} className="text-[#1d1d1f]/40 hover:text-brand-danger transition-colors">
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button onClick={() => onNavigate('auth')} className="bg-[#1d1d1f] text-white px-6 py-2 rounded-full text-[13px] font-semibold hover:bg-[#323234] transition-all">Login</button>
            )}
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-600 p-2 rounded-full bg-slate-100">
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-slate-200 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              <button onClick={() => { onNavigate('how-it-works'); setIsOpen(false); }} className="block w-full text-left px-3 py-2 text-slate-600 font-medium">How It Works</button>
              <button onClick={() => { onNavigate('science'); setIsOpen(false); }} className="block w-full text-left px-3 py-2 text-slate-600 font-medium">Science</button>
              <button onClick={() => { onNavigate('shop'); setIsOpen(false); }} className="block w-full text-left px-3 py-2 text-slate-600 font-medium">Shop</button>
              <button onClick={() => { onNavigate('sync'); setIsOpen(false); }} className="block w-full text-left px-3 py-2 text-slate-600 font-medium">Health Sync</button>
              <button onClick={() => { onNavigate('faq'); setIsOpen(false); }} className="block w-full text-left px-3 py-2 text-slate-600 font-medium">FAQ</button>
              {user ? (
                <>
                  <button onClick={() => { onNavigate('dashboard'); setIsOpen(false); }} className="block w-full text-left px-3 py-2 text-brand-accent font-medium">Dashboard</button>
                  <button onClick={() => { onNavigate('profile'); setIsOpen(false); }} className="block w-full text-left px-3 py-2 text-slate-600 font-medium">Profile</button>
                  <button onClick={onLogout} className="block w-full text-left px-3 py-2 text-brand-danger font-medium">Logout</button>
                </>
              ) : (
                <button onClick={() => { onNavigate('auth'); setIsOpen(false); }} className="block w-full text-center btn-primary mt-4">Login</button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const LiveAudioAssistant = ({ onClose }: { onClose: () => void }) => {
  const [isConnecting, setIsConnecting] = useState(true);
  const [isActive, setIsActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const audioContextRef = React.useRef<AudioContext | null>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const processorRef = React.useRef<ScriptProcessorNode | null>(null);
  const sessionRef = React.useRef<any>(null);
  const audioQueueRef = React.useRef<Int16Array[]>([]);
  const isPlayingRef = React.useRef(false);

  const stopAudio = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
    if (sessionRef.current) {
      sessionRef.current.close();
    }
    setIsActive(false);
  };

  const startAudio = async () => {
    try {
      setIsConnecting(true);
      setError(null);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioContext = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      const session = await connectLiveAudio({
        onopen: () => {
          setIsConnecting(false);
          setIsActive(true);
          console.log("Live API connected");
        },
        onmessage: (message: LiveServerMessage) => {
          if (message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data) {
            const base64Data = message.serverContent.modelTurn.parts[0].inlineData.data;
            const binaryString = window.atob(base64Data);
            const bytes = new Uint8Array(binaryString.length);
            for (let i = 0; i < binaryString.length; i++) {
              bytes[i] = binaryString.charCodeAt(i);
            }
            const pcmData = new Int16Array(bytes.buffer);
            audioQueueRef.current.push(pcmData);
            if (!isPlayingRef.current) {
              playNextInQueue();
            }
          }
          if (message.serverContent?.interrupted) {
            audioQueueRef.current = [];
            isPlayingRef.current = false;
          }
        },
        onerror: (err) => {
          console.error("Live API error:", err);
          setError("Connection error. Please try again.");
          stopAudio();
        },
        onclose: () => {
          console.log("Live API closed");
          setIsActive(false);
        }
      });
      sessionRef.current = session;

      processor.onaudioprocess = (e) => {
        if (!isActive || isMuted) return;
        const inputData = e.inputBuffer.getChannelData(0);
        // Convert Float32 to Int16
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
        }
        // Convert to Base64
        const base64Data = window.btoa(String.fromCharCode(...new Uint8Array(pcmData.buffer)));
        session.sendRealtimeInput({
          media: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
        });
      };

      source.connect(processor);
      processor.connect(audioContext.destination);

    } catch (err) {
      console.error("Failed to start audio assistant:", err);
      setError("Microphone access denied or not supported.");
      setIsConnecting(false);
    }
  };

  const playNextInQueue = async () => {
    if (audioQueueRef.current.length === 0 || !audioContextRef.current) {
      isPlayingRef.current = false;
      return;
    }

    isPlayingRef.current = true;
    const pcmData = audioQueueRef.current.shift()!;
    const floatData = new Float32Array(pcmData.length);
    for (let i = 0; i < pcmData.length; i++) {
      floatData[i] = pcmData[i] / 0x7FFF;
    }

    const buffer = audioContextRef.current.createBuffer(1, floatData.length, 16000);
    buffer.getChannelData(0).set(floatData);

    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.onended = () => playNextInQueue();
    source.start();
  };

  useEffect(() => {
    startAudio();
    return () => stopAudio();
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="absolute inset-0 bg-brand-primary z-50 flex flex-col items-center justify-center p-8 text-white"
    >
      <button 
        onClick={onClose}
        className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-full transition-colors"
      >
        <X className="w-6 h-6" />
      </button>

      <div className="relative mb-12">
        <div className={`w-32 h-32 rounded-full bg-white/10 flex items-center justify-center relative z-10 ${isActive ? 'animate-pulse' : ''}`}>
          {isConnecting ? (
            <Loader2 className="w-12 h-12 animate-spin text-brand-accent" />
          ) : (
            <div className="flex items-center justify-center">
              <div className={`absolute inset-0 rounded-full bg-brand-accent/20 animate-ping ${isActive ? 'block' : 'hidden'}`} />
              <HeartPulse className="w-16 h-16 text-brand-accent" />
            </div>
          )}
        </div>
      </div>

      <div className="text-center mb-12">
        <h3 className="text-2xl font-display font-bold mb-2">
          {isConnecting ? 'Connecting...' : isActive ? 'Listening...' : 'Assistant Ready'}
        </h3>
        <p className="text-white/60 text-sm max-w-xs mx-auto">
          {error || 'Speak naturally to discuss your heart health and test results.'}
        </p>
      </div>

      <div className="flex items-center space-x-6">
        <button 
          onClick={() => setIsMuted(!isMuted)}
          className={`p-4 rounded-full transition-all ${isMuted ? 'bg-red-500 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
        >
          {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        </button>
        
        <div className="flex space-x-1">
          {[1, 2, 3, 4, 5].map((i) => (
            <motion.div 
              key={i}
              animate={{ 
                height: isActive && !isMuted ? [10, 30, 10] : 10 
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 0.5, 
                delay: i * 0.1 
              }}
              className="w-1 bg-brand-accent rounded-full"
            />
          ))}
        </div>

        <button 
          className="p-4 rounded-full bg-white/10 text-white hover:bg-white/20 transition-all"
        >
          <Volume2 className="w-6 h-6" />
        </button>
      </div>

      {error && (
        <button 
          onClick={startAudio}
          className="mt-8 px-6 py-2 bg-white text-brand-primary rounded-full font-bold text-sm"
        >
          Retry Connection
        </button>
      )}
    </motion.div>
  );
};

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: 'Hi! I am your StopCardiac assistant. You can track your sample or view reports here. How can I help you today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (text?: string) => {
    const userMsg = text || input;
    if (!userMsg.trim()) return;
    
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      // Real logic for tracking/reports using Supabase
      if (userMsg.toLowerCase().includes('track') || userMsg.toLowerCase().includes('report')) {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          const { data: orders } = await supabase
            .from('orders')
            .select('*')
            .eq('user_id', session.user.id)
            .order('created_at', { ascending: false });
          
          if (orders && orders.length > 0) {
            const latest = orders[0];
            const statusText = latest.status.split('_').map((s: string) => s.charAt(0).toUpperCase() + s.slice(1)).join(' ');
            setMessages(prev => [...prev, { 
              role: 'model', 
              text: `I found your latest order #${latest.id.slice(0, 8)}. Status: ${statusText}. It was placed on ${new Date(latest.created_at).toLocaleDateString()}.` 
            }]);
          } else {
            setMessages(prev => [...prev, { role: 'model', text: "I couldn't find any active orders for your account. Would you like to order a test kit?" }]);
          }
        } else {
          setMessages(prev => [...prev, { role: 'model', text: "Please sign in to track your orders or view reports." }]);
        }
        setIsLoading(false);
        return;
      }

      const response = await getChatResponse(userMsg, []);
      setMessages(prev => [...prev, { role: 'model', text: response || 'I am sorry, I could not process that.' }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: 'Error connecting to AI. Please try again later.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="bg-white/80 backdrop-blur-2xl rounded-[2rem] shadow-2xl border border-white/20 w-80 sm:w-96 h-[550px] flex flex-col mb-4 overflow-hidden relative"
          >
            {isVoiceActive ? (
              <LiveAudioAssistant onClose={() => setIsVoiceActive(false)} />
            ) : (
              <>
                <div className="bg-brand-primary p-6 text-white flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-brand-accent rounded-full flex items-center justify-center mr-3">
                      <Activity className="w-4 h-4 text-white" />
                    </div>
                    <span className="font-bold tracking-tight">StopCardiac AI</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => setIsVoiceActive(true)}
                      className="hover:bg-white/10 p-2 rounded-full transition-colors"
                      title="Start Voice Conversation"
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                    <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-1 rounded-full"><X className="w-5 h-5" /></button>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#f5f5f7]/50">
                  {messages.map((msg, i) => (
                    <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[85%] p-4 rounded-2xl text-[13px] leading-relaxed ${
                        msg.role === 'user' 
                          ? 'bg-[#0071e3] text-white rounded-tr-none shadow-lg shadow-blue-500/20' 
                          : 'bg-white text-[#1d1d1f] border border-black/[0.03] rounded-tl-none shadow-sm'
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-white text-slate-400 border border-black/[0.03] p-4 rounded-2xl rounded-tl-none text-[13px] animate-pulse shadow-sm">
                        Thinking...
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-4 bg-white/80 border-t border-black/[0.03]">
                  <div className="flex flex-wrap gap-2 mb-4">
                    <button onClick={() => handleSend('Track my sample')} className="text-[10px] font-bold uppercase tracking-widest bg-[#f5f5f7] hover:bg-[#e8e8ed] px-3 py-1.5 rounded-full transition-colors">Track Sample</button>
                    <button onClick={() => handleSend('View my reports')} className="text-[10px] font-bold uppercase tracking-widest bg-[#f5f5f7] hover:bg-[#e8e8ed] px-3 py-1.5 rounded-full transition-colors">My Reports</button>
                    <button onClick={() => handleSend('How to swab?')} className="text-[10px] font-bold uppercase tracking-widest bg-[#f5f5f7] hover:bg-[#e8e8ed] px-3 py-1.5 rounded-full transition-colors">Swab Help</button>
                  </div>
                  <div className="flex space-x-2">
                    <input 
                      type="text" 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                      placeholder="Ask anything..."
                      className="flex-1 bg-[#f5f5f7] border border-transparent rounded-full px-5 py-3 text-[13px] focus:bg-white focus:border-[#0071e3] outline-none transition-all"
                    />
                    <button 
                      onClick={() => handleSend()}
                      disabled={isLoading}
                      className="bg-[#0071e3] text-white p-3 rounded-full hover:bg-[#0077ed] transition-all shadow-lg shadow-blue-500/20"
                    >
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="bg-brand-primary text-white p-5 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center group"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6 group-hover:rotate-12 transition-transform" />}
      </button>
    </div>
  );
};

// --- Pages ---

const ProcessFlowSection = () => {
  const steps = [
    { title: "Buccal Swab", desc: "A simple 30-second cheek swab at home.", icon: <Activity /> },
    { title: "DNA Extraction", desc: "Our lab isolates your genetic blueprint.", icon: <Dna /> },
    { title: "Sequencing", desc: "High-throughput analysis of MYBPC3.", icon: <Search /> },
    { title: "Expert Review", desc: "Cardiologists validate every result.", icon: <ShieldCheck /> },
    { title: "Your Report", desc: "Actionable insights delivered securely.", icon: <FileText /> }
  ];

  return (
    <section className="py-24 bg-[#f5f5f7] overflow-hidden relative">
      <DNABackground />
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold text-[#1d1d1f] mb-4">The Flow of Discovery</h2>
          <p className="text-xl text-[#1d1d1f]/50">From a single swab to a lifetime of heart health awareness.</p>
        </div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#0071e3]/10 to-transparent hidden lg:block" />
          
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8 relative z-10">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="apple-card p-8 flex flex-col items-center text-center group"
              >
                <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                  {React.cloneElement(step.icon as React.ReactElement, { className: "w-8 h-8 text-[#0071e3]" })}
                </div>
                <h4 className="text-xl font-bold text-[#1d1d1f] mb-3">{step.title}</h4>
                <p className="text-sm text-[#1d1d1f]/50 leading-relaxed font-medium">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const RiskAssessmentQuiz = () => {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<{ question: string, answer: string }[]>([]);
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const questions = [
    "Do you have a family history of sudden heart failure or cardiomyopathy?",
    "Are you of South Asian (Indian, Pakistani, Bangladeshi, Sri Lankan) descent?",
    "Have you ever experienced unexplained fainting, dizziness, or chest pain during exercise?",
    "Are you over the age of 25 and looking to proactively manage your heart health?"
  ];

  const handleAnswer = async (answer: string) => {
    const newAnswers = [...answers, { question: questions[step], answer }];
    setAnswers(newAnswers);

    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      setIsLoading(true);
      try {
        const assessment = await evaluateRisk(newAnswers);
        setResult(assessment || "Based on your answers, we recommend consulting a specialist.");
      } catch (error) {
        setResult("Error connecting to AI. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    }
  };

  return (
    <div className="apple-card p-10 md:p-16 bg-white/80 backdrop-blur-xl border border-white/20 shadow-2xl overflow-hidden relative">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#0071e3]/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#10b981]/5 rounded-full blur-3xl -z-10" />
      
      <div className="relative z-10">
        {!result ? (
          <div className="max-w-2xl mx-auto text-center">
            <div className="flex items-center justify-center space-x-3 mb-8">
              <div className="w-10 h-10 bg-[#0071e3] rounded-full flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#0071e3]">AI Risk Assessment</span>
            </div>
            
            <h3 className="text-3xl font-display font-bold text-[#1d1d1f] mb-10">
              {questions[step]}
            </h3>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <button 
                onClick={() => handleAnswer("Yes")}
                className="px-12 py-4 bg-[#1d1d1f] text-white rounded-2xl font-bold hover:bg-black transition-all shadow-xl shadow-black/10"
              >
                Yes
              </button>
              <button 
                onClick={() => handleAnswer("No")}
                className="px-12 py-4 bg-white text-[#1d1d1f] border border-black/[0.05] rounded-2xl font-bold hover:bg-[#f5f5f7] transition-all"
              >
                No
              </button>
            </div>
            
            <div className="mt-12 flex justify-center space-x-2">
              {questions.map((_, i) => (
                <div key={i} className={`w-2 h-2 rounded-full transition-all duration-500 ${i === step ? 'w-8 bg-[#0071e3]' : 'bg-slate-200'}`} />
              ))}
            </div>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto text-center"
          >
            {isLoading ? (
              <div className="py-12">
                <div className="w-12 h-12 border-4 border-[#0071e3] border-t-transparent rounded-full animate-spin mx-auto mb-6" />
                <p className="text-slate-500 font-medium">AI is analyzing your risk factors...</p>
              </div>
            ) : (
              <>
                <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-8">
                  <ShieldCheck className="w-10 h-10" />
                </div>
                <h3 className="text-3xl font-display font-bold text-[#1d1d1f] mb-6">Your Assessment</h3>
                <p className="text-lg text-[#1d1d1f]/70 leading-relaxed mb-10 font-medium italic">
                  "{result}"
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <button 
                    onClick={() => setStep(0) || setAnswers([]) || setResult(null)}
                    className="px-8 py-4 bg-[#f5f5f7] text-[#1d1d1f] rounded-2xl font-bold hover:bg-[#e8e8ed] transition-all"
                  >
                    Retake Quiz
                  </button>
                  <button className="px-8 py-4 bg-[#0071e3] text-white rounded-2xl font-bold hover:bg-[#0077ed] transition-all shadow-lg shadow-blue-500/20">
                    Order Test Kit
                  </button>
                </div>
              </>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
};

const HomePage = ({ onOrder, onNavigate }: { onOrder: () => void, onNavigate: (page: string) => void }) => {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-white">
        <DNABackground />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-7"
            >
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 mb-8">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-blue-600">Now Available in India</span>
              </div>
              
              <h1 className="text-6xl md:text-[112px] font-display font-bold text-[#1d1d1f] tracking-tight leading-[0.88] mb-10">
                A hidden <br />
                gene. <br />
                <span className="text-[#0071e3] relative inline-block">
                  Zero warning.
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ delay: 1, duration: 0.8 }}
                    className="absolute -bottom-2 left-0 h-2 bg-blue-100 -z-10"
                  />
                </span>
              </h1>
              
              <p className="text-xl md:text-2xl text-[#1d1d1f]/50 mb-12 font-medium leading-relaxed max-w-xl">
                1 in 25 Indians carry the MYBPC3 mutation. It's the silent cause of sudden heart failure in healthy young people. 
                <span className="text-[#1d1d1f]"> Protect your family with one simple test.</span>
              </p>
              
              <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
                <button onClick={onOrder} className="btn-accent w-full sm:w-auto px-12 py-5 text-lg group">
                  Order Your Test
                  <ArrowRight className="inline-block ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <button onClick={() => onNavigate('how-it-works')} className="btn-outline w-full sm:w-auto px-12 py-5 text-lg">
                  See Your Journey
                </button>
              </div>

              <div className="mt-16 flex items-center space-x-8 opacity-40 grayscale">
                <div className="text-xs font-bold uppercase tracking-widest">Trusted By</div>
                <div className="flex space-x-6 items-center">
                  <div className="h-6 w-20 bg-slate-400 rounded-sm" />
                  <div className="h-6 w-24 bg-slate-400 rounded-sm" />
                  <div className="h-6 w-16 bg-slate-400 rounded-sm" />
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
              className="lg:col-span-5 relative"
            >
              <div className="relative z-10">
                <DNAVisual />
              </div>
              {/* Floating stats cards */}
              <motion.div 
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-10 -right-10 apple-card p-6 bg-white/80 backdrop-blur-xl border border-white/20 shadow-2xl z-20 hidden xl:block"
              >
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  </div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Accuracy</span>
                </div>
                <div className="text-3xl font-display font-bold text-brand-primary">99.9%</div>
                <div className="text-[10px] text-slate-400 font-medium mt-1">Clinical Grade Sequencing</div>
              </motion.div>

              <motion.div 
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                className="absolute -bottom-10 -left-10 apple-card p-6 bg-white/80 backdrop-blur-xl border border-white/20 shadow-2xl z-20 hidden xl:block"
              >
                <div className="flex items-center space-x-3 mb-2">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <Clock className="w-4 h-4 text-blue-600" />
                  </div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Turnaround</span>
                </div>
                <div className="text-3xl font-display font-bold text-brand-primary">14 Days</div>
                <div className="text-[10px] text-slate-400 font-medium mt-1">From Swab to Report</div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      <ProcessFlowSection />

      {/* AI Risk Assessment */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-display font-bold text-[#1d1d1f] mb-4">Not sure if you need it?</h2>
            <p className="text-xl text-[#1d1d1f]/50">Take our 1-minute AI-powered risk assessment.</p>
          </div>
          <RiskAssessmentQuiz />
        </div>
      </section>

      {/* Expert Quotes */}
      <section className="py-20 bg-[#f5f5f7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="apple-card p-10">
              <p className="text-2xl font-display font-medium text-brand-primary mb-8 italic">
                "Early detection of the MYBPC3 mutation is the single most effective way to prevent sudden cardiac death in South Asian populations."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-slate-200 rounded-full mr-4"></div>
                <div>
                  <div className="font-bold text-brand-primary">Dr. K. S. Reddy</div>
                  <div className="text-sm text-slate-500">Leading Cardiologist & Geneticist</div>
                </div>
              </div>
            </div>
            <div className="apple-card p-10">
              <p className="text-2xl font-display font-medium text-brand-primary mb-8 italic">
                "StopCardiac is bridging the gap between advanced genomics and everyday healthcare. This is the future of preventive medicine."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-slate-200 rounded-full mr-4"></div>
                <div>
                  <div className="font-bold text-brand-primary">Dr. Soumya Swaminathan</div>
                  <div className="text-sm text-slate-500">Public Health Expert</div>
                </div>
              </div>
            </div>
            <div className="apple-card p-10">
              <p className="text-2xl font-display font-medium text-brand-primary mb-8 italic">
                "The ability to identify high-risk genetic variants like MYBPC3 at scale is a paradigm shift in how we approach cardiovascular health."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-slate-200 rounded-full mr-4"></div>
                <div>
                  <div className="font-bold text-brand-primary">Dr. Eric Topol</div>
                  <div className="text-sm text-slate-500">Cardiologist & Digital Health Pioneer</div>
                </div>
              </div>
            </div>
            <div className="apple-card p-10">
              <p className="text-2xl font-display font-medium text-brand-primary mb-8 italic">
                "Genomic medicine is no longer a future promise; it's a present-day tool for saving lives in vulnerable populations."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-slate-200 rounded-full mr-4"></div>
                <div>
                  <div className="font-bold text-brand-primary">Dr. Francis Collins</div>
                  <div className="text-sm text-slate-500">Former Director, NIH</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Global Factsheet */}
      <section className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-6xl font-display font-bold text-brand-primary mb-6">Global Factsheet</h2>
            <p className="text-xl text-slate-500 max-w-2xl mx-auto">The silent impact of MYBPC3 around the world.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {[
              { label: "India", value: "1 in 25", desc: "Carry the mutation, the highest prevalence globally." },
              { label: "South Asia", value: "100M+", desc: "People at risk across the subcontinent." },
              { label: "Global HCM", value: "30%", desc: "Of cases are linked to this specific mutation." }
            ].map((fact, i) => (
              <div key={i} className="text-center p-10 apple-card">
                <div className="text-sm font-bold uppercase tracking-widest text-slate-400 mb-4">{fact.label}</div>
                <div className="text-5xl font-display font-bold text-brand-accent mb-4">{fact.value}</div>
                <p className="text-slate-600 font-medium">{fact.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Scientific Research */}
      <section className="py-32 bg-[#f5f5f7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="apple-card p-12 md:p-20 flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1">
              <h2 className="text-4xl font-display font-bold text-brand-primary mb-8 text-center lg:text-left">Backed by Decades of Research</h2>
              <p className="text-lg text-slate-600 mb-10 leading-relaxed text-center lg:text-left">
                Our screening process is built on peer-reviewed studies from Nature, The Lancet, and the Journal of Biological Chemistry. We don't just test; we provide evidence-based insights.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <a href="https://pubmed.ncbi.nlm.nih.gov/19151713/" target="_blank" className="flex items-center p-4 bg-white rounded-2xl border border-slate-100 hover:border-brand-accent transition-colors">
                  <FileText className="w-5 h-5 text-brand-accent mr-3" />
                  <span className="text-sm font-bold text-slate-700">Nature Genetics Study</span>
                </a>
                <a href="https://pubmed.ncbi.nlm.nih.gov/25583994/" target="_blank" className="flex items-center p-4 bg-white rounded-2xl border border-slate-100 hover:border-brand-accent transition-colors">
                  <FileText className="w-5 h-5 text-brand-accent mr-3" />
                  <span className="text-sm font-bold text-slate-700">JBC Research Paper</span>
                </a>
              </div>
            </div>
            <div className="w-full lg:w-1/3">
              <div className="aspect-square bg-white rounded-[3rem] shadow-inner flex items-center justify-center p-12">
                <Activity className="w-full h-full text-brand-accent opacity-20" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Facts Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-brand-primary mb-4">The Facts That Could Save Your Life</h2>
            <p className="text-slate-500 max-w-2xl mx-auto">Understanding the risk is the first step toward prevention.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { 
                title: "1 in 25 Indians", 
                desc: "Have the MYBPC3 25bp deletion: a silent genetic time bomb.",
                icon: <AlertTriangle className="w-8 h-8 text-brand-danger" />
              },
              { 
                title: "Sudden Cardiac Death", 
                desc: "Hypertrophic Cardiomyopathy (HCM) is the #1 cause of sudden cardiac death in young people.",
                icon: <Activity className="w-8 h-8 text-brand-warning" />
              },
              { 
                title: "Silent Symptoms", 
                desc: "Most people struck by HCM seemed 100% healthy before their first (and often final) event.",
                icon: <Shield className="w-8 h-8 text-brand-info" />
              },
              { 
                title: "Abnormal Protein", 
                desc: "This mutation causes abnormal protein buildup — you feel normal in your 20s, but are at risk in your 40s and 50s.",
                icon: <Info className="w-8 h-8 text-brand-accent" />
              },
              { 
                title: "Economic Impact", 
                desc: "By 2030, heart failure will cost India 17.9 million productive years – that’s 10x more than the US.",
                icon: <Activity className="w-8 h-8 text-emerald-500" />
              },
              { 
                title: "Global Risk", 
                desc: "The MYBPC3 mutation is responsible for 15–30% of all known HCM mutations globally.",
                icon: <Heart className="w-8 h-8 text-rose-500" />
              }
            ].map((fact, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:shadow-lg transition-all"
              >
                <div className="mb-6">{fact.icon}</div>
                <h3 className="text-xl font-bold text-brand-primary mb-3">{fact.title}</h3>
                <p className="text-slate-600 leading-relaxed">{fact.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-brand-primary mb-4">How It Works in 3 Easy Steps</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { step: "01", title: "Order Your Kit", desc: "Place your order. The test kit arrives at your home in a few days.", icon: <Package /> },
              { step: "02", title: "Swab and Send", desc: "Just spit into the tube, seal it, and use the prepaid envelope to mail it back.", icon: <Activity /> },
              { step: "03", title: "Get Your Report", desc: "See your personalized results securely on your dashboard in about 2 weeks.", icon: <FileText /> }
            ].map((item, i) => (
              <div key={i} className="relative text-center">
                <div className="w-20 h-20 bg-white rounded-2xl shadow-sm border border-slate-200 flex items-center justify-center mx-auto mb-8 text-brand-accent">
                  {React.cloneElement(item.icon as React.ReactElement, { className: "w-10 h-10" })}
                </div>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 text-4xl font-bold text-slate-100 -z-10">{item.step}</div>
                <h3 className="text-xl font-bold text-brand-primary mb-4">{item.title}</h3>
                <p className="text-slate-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Science Simplified */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
            <div className="order-2 lg:order-1">
              <h2 className="text-3xl md:text-4xl font-bold text-brand-primary mb-6">What does this test look for?</h2>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                We test for a single change in your MYBPC3 gene. If you carry it, you may have a higher risk for serious heart problems, even if you feel healthy today. Knowing early means having time to act — and protect your future.
              </p>
              <div className="space-y-4">
                <div className="flex items-center p-4 bg-slate-50 rounded-2xl">
                  <div className="w-10 h-10 bg-brand-accent/10 rounded-full flex items-center justify-center mr-4">
                    <CheckCircle2 className="w-6 h-6 text-brand-accent" />
                  </div>
                  <span className="font-medium text-slate-700">Simple spit swab at home</span>
                </div>
                <div className="flex items-center p-4 bg-slate-50 rounded-2xl">
                  <div className="w-10 h-10 bg-brand-accent/10 rounded-full flex items-center justify-center mr-4">
                    <CheckCircle2 className="w-6 h-6 text-brand-accent" />
                  </div>
                  <span className="font-medium text-slate-700">One test. Once in your life.</span>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2 mb-12 lg:mb-0">
              <img 
                src="https://images.unsplash.com/photo-1530026405186-ed1f139313f8?auto=format&fit=crop&q=80&w=1000" 
                alt="DNA Visualization" 
                className="rounded-[3rem] shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-brand-primary rounded-[3rem] p-12 md:p-20 text-white relative overflow-hidden">
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-8">Science Simplified. Trust Guaranteed.</h2>
                <div className="space-y-6">
                  <div className="flex items-start">
                    <CheckCircle2 className="w-6 h-6 text-brand-accent mt-1 mr-4 flex-shrink-0" />
                    <div>
                      <h4 className="font-bold mb-1">Doctor-Reviewed Results</h4>
                      <p className="text-slate-300 text-sm">Every report is signed by a licensed cardiologist for your peace of mind.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle2 className="w-6 h-6 text-brand-accent mt-1 mr-4 flex-shrink-0" />
                    <div>
                      <h4 className="font-bold mb-1">Certified Laboratories</h4>
                      <p className="text-slate-300 text-sm">Our testing lab is internationally certified and follows strict quality standards.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle2 className="w-6 h-6 text-brand-accent mt-1 mr-4 flex-shrink-0" />
                    <div>
                      <h4 className="font-bold mb-1">Privacy Protected</h4>
                      <p className="text-slate-300 text-sm">HIPAA-compliant, secure technology ensures your data is for your eyes only.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-center lg:text-right">
                <div className="inline-block p-8 bg-white/10 backdrop-blur-lg rounded-3xl border border-white/20">
                  <p className="text-2xl font-medium mb-6">One simple test could give you a lifetime of peace of mind.</p>
                  <button onClick={onOrder} className="bg-brand-accent text-white px-10 py-5 rounded-2xl font-bold text-xl hover:bg-emerald-600 transition-all shadow-xl shadow-emerald-500/20">
                    Order Your Test Now
                  </button>
                </div>
              </div>
            </div>
            {/* Decorative circles */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
          </div>
        </div>
      </section>
    </div>
  );
};

const AuthPage = ({ onAuthSuccess }: { onAuthSuccess: (user: UserType) => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (isLogin) {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        
        // Fetch profile
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();
        
        if (profileError) throw profileError;
        onAuthSuccess(profile);
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              name,
            }
          }
        });
        if (error) throw error;
        
        // Profiles are usually created via Supabase triggers, 
        // but for this demo we'll assume the profile exists or we fetch it
        if (data.user) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', data.user.id)
            .single();
          
          if (profile) onAuthSuccess(profile);
          else {
            // Fallback if trigger hasn't run yet
            onAuthSuccess({ id: data.user.id, email: data.user.email!, name, role: 'user' });
          }
        }
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-20 px-4 bg-[#f5f5f7] flex items-center justify-center relative overflow-hidden">
      <DNABackground />
      <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
        {/* Left Side: Navigation Details / Benefits */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="hidden lg:block space-y-8"
        >
          <h2 className="text-4xl md:text-5xl font-display font-bold text-[#1d1d1f] leading-tight">
            Your heart health, <br />
            <span className="text-[#0071e3]">all in one place.</span>
          </h2>
          <p className="text-xl text-[#1d1d1f]/50 font-medium max-w-md">
            Join the thousands of Indians taking control of their genetic destiny.
          </p>
          
          <div className="grid grid-cols-1 gap-6">
            {[
              { title: "Register Your Kit", desc: "Activate your sample ID in seconds.", icon: <Package /> },
              { title: "Live Tracking", desc: "Follow your sample from home to our lab.", icon: <Clock /> },
              { title: "Expert Reports", desc: "View detailed, cardiologist-signed results.", icon: <FileText /> },
              { title: "Free Counseling", desc: "15-minute session with a genetic expert.", icon: <MessageSquare /> }
            ].map((item, i) => (
              <div key={i} className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center flex-shrink-0">
                  {React.cloneElement(item.icon as React.ReactElement, { className: "w-5 h-5 text-[#0071e3]" })}
                </div>
                <div>
                  <h4 className="font-bold text-[#1d1d1f]">{item.title}</h4>
                  <p className="text-sm text-[#1d1d1f]/50">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Right Side: Auth Form */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[2.5rem] shadow-2xl p-8 md:p-12 border border-black/[0.02]"
        >
          <div className="text-center mb-10">
            <div className="lg:hidden mb-6">
              <Heart className="w-12 h-12 text-[#0071e3] mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-[#1d1d1f]">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
            </div>
            <div className="hidden lg:block">
              <h3 className="text-2xl font-bold text-[#1d1d1f]">{isLogin ? 'Sign In' : 'Get Started'}</h3>
              <p className="text-slate-500 mt-2">Access your secure health portal.</p>
            </div>
          </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-xl text-sm flex items-center">
            <AlertTriangle className="w-4 h-4 mr-2" /> {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {!isLogin && (
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Full Name</label>
              <input 
                type="text" 
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none transition-all"
                placeholder="John Doe"
              />
            </div>
          )}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Email Address</label>
            <input 
              type="email" 
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none transition-all"
              placeholder="name@example.com"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Password</label>
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-accent focus:border-transparent outline-none transition-all"
              placeholder="••••••••"
            />
          </div>

          <button type="submit" className="w-full btn-primary py-4 text-lg">
            {isLogin ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="mt-8 pt-8 border-t border-slate-100">
          <button className="w-full flex items-center justify-center space-x-3 px-4 py-3 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors">
            <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
            <span className="font-medium text-slate-700">Continue with Google</span>
          </button>
        </div>

        <p className="mt-8 text-center text-slate-500 text-sm">
          {isLogin ? "Don't have an account?" : "Already have an account?"}{' '}
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-brand-accent font-bold hover:underline"
          >
            {isLogin ? 'Sign Up' : 'Sign In'}
          </button>
        </p>

        {isLogin && (
          <div className="mt-6 p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Test Credentials</p>
            <div className="flex justify-between text-xs font-mono text-slate-600">
              <span>demo@example.com</span>
              <span>password123</span>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  </div>
  );
};

const Dashboard = ({ user, onNavigate }: { user: UserType, onNavigate: (page: string, params?: any) => void }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (data) {
        setOrders(data);
        setIsLoading(false);
      }
    };
    fetchOrders();
  }, [user.id]);

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'report_ready': return 'text-emerald-600 bg-emerald-50';
      case 'ordered': return 'text-blue-600 bg-blue-50';
      case 'shipped': return 'text-indigo-600 bg-indigo-50';
      case 'sample_received': return 'text-amber-600 bg-amber-50';
      default: return 'text-slate-600 bg-slate-50';
    }
  };

  const formatStatus = (status: string) => status.split('_').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' ');

  return (
    <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto relative overflow-hidden">
      <DNABackground />
      <div className="relative z-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-12">
          <div>
            <h1 className="text-4xl font-display font-bold text-brand-primary">Welcome, {user.name}</h1>
            <p className="text-lg text-slate-500 font-medium">Your heart health overview.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 mt-6 md:mt-0">
            <button onClick={() => onNavigate('checkout')} className="btn-accent flex items-center justify-center py-3 px-8">
              <Package className="w-5 h-5 mr-2" /> Register Kit
            </button>
            <button onClick={() => onNavigate('checkout')} className="btn-primary flex items-center justify-center py-3 px-8">
              <ShoppingBag className="w-5 h-5 mr-2" /> Order New Test
            </button>
          </div>
        </div>

        {/* Bento Grid Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="md:col-span-2 apple-card p-8 bg-gradient-to-br from-[#1d1d1f] to-[#323234] text-white flex flex-col justify-between min-h-[200px]">
            <div className="flex justify-between items-start">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
                <Activity className="w-6 h-6 text-blue-400" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Active Monitoring</span>
            </div>
            <div>
              <div className="text-4xl font-display font-bold mb-1">Heart Status</div>
              <div className="text-white/60 font-medium">No active risks detected in latest sync.</div>
            </div>
          </div>

          <div className="apple-card p-8 bg-white flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Orders</span>
            </div>
            <div>
              <div className="text-4xl font-display font-bold mb-1 text-brand-primary">{orders.length}</div>
              <div className="text-slate-400 text-sm font-medium">Total Test Kits</div>
            </div>
          </div>

          <div className="apple-card p-8 bg-white flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-emerald-600" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Reports</span>
            </div>
            <div>
              <div className="text-4xl font-display font-bold mb-1 text-brand-primary">
                {orders.filter(o => o.status === 'report_ready').length}
              </div>
              <div className="text-slate-400 text-sm font-medium">Available Results</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Orders List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-2xl font-display font-bold text-brand-primary flex items-center">
                <Clock className="w-6 h-6 mr-3 text-brand-accent" /> Recent Activity
              </h2>
              <button className="text-sm font-bold text-brand-accent hover:underline">View All</button>
            </div>
            
            {isLoading ? (
              <div className="animate-pulse space-y-4">
                {[1, 2].map(i => <div key={i} className="h-32 bg-white rounded-3xl border border-slate-100"></div>)}
              </div>
            ) : orders.length > 0 ? (
              orders.map(order => (
                <motion.div 
                  key={order.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="apple-card p-8 bg-white"
                >
                  <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center">
                        <Package className="w-6 h-6 text-slate-400" />
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 font-bold uppercase tracking-widest">Order #{order.id.slice(0, 8)}</div>
                        <div className="text-brand-primary font-bold text-lg">Genetic Screening Kit</div>
                      </div>
                    </div>
                    <span className={`px-5 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest ${getStatusColor(order.status)}`}>
                      {formatStatus(order.status)}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    {[
                      { s: 'ordered', icon: <Package />, label: 'Ordered' },
                      { s: 'shipped', icon: <ArrowRight />, label: 'Shipped' },
                      { s: 'sample_received', icon: <Activity />, label: 'In Lab' },
                      { s: 'report_ready', icon: <FileText />, label: 'Ready' }
                    ].map((step, i) => {
                      const isDone = order.status === step.s || (i === 0 && order.status !== 'ordered') || (i === 1 && ['sample_received', 'report_ready'].includes(order.status)) || (i === 2 && order.status === 'report_ready');
                      return (
                        <div key={i} className="flex flex-col items-center relative">
                          {i < 3 && (
                            <div className={`absolute top-5 left-1/2 w-full h-[2px] -z-10 ${isDone ? 'bg-brand-accent/20' : 'bg-slate-100'}`} />
                          )}
                          <div className={`w-10 h-10 rounded-full border-4 border-white flex items-center justify-center transition-all duration-500 ${
                            isDone ? 'bg-brand-accent text-white shadow-lg shadow-blue-500/20 scale-110' : 'bg-slate-100 text-slate-300'
                          }`}>
                            {React.cloneElement(step.icon as React.ReactElement, { className: "w-4 h-4" })}
                          </div>
                          <span className={`text-[10px] font-bold uppercase tracking-widest mt-3 ${isDone ? 'text-brand-primary' : 'text-slate-300'}`}>
                            {step.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                    <div className="text-xs text-slate-400 font-medium">
                      Placed on {new Date(order.created_at).toLocaleDateString()}
                    </div>
                    <div className="flex space-x-3">
                      <button className="text-xs font-bold text-slate-400 hover:text-brand-primary transition-colors">Track Shipment</button>
                      {order.status === 'report_ready' && (
                        <button 
                          onClick={() => onNavigate('report', { orderId: order.id })}
                          className="text-xs font-bold text-brand-accent hover:underline"
                        >
                          View Report
                        </button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="apple-card p-16 text-center bg-white">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Package className="w-10 h-10 text-slate-200" />
                </div>
                <h3 className="text-xl font-bold text-brand-primary mb-2">No active orders</h3>
                <p className="text-slate-400 mb-8 max-w-xs mx-auto">You haven't ordered any test kits yet. Start your heart health journey today.</p>
                <button onClick={() => onNavigate('checkout')} className="btn-primary">Order Test Kit</button>
              </div>
            )}
          </div>

          {/* Sidebar Actions */}
          <div className="space-y-8">
            <div className="apple-card p-8 bg-white">
              <h3 className="text-lg font-display font-bold text-brand-primary mb-6">Quick Actions</h3>
              <div className="space-y-4">
                <button onClick={() => onNavigate('sync')} className="w-full flex items-center p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-colors group">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center mr-4 shadow-sm group-hover:scale-110 transition-transform">
                    <RefreshCw className="w-5 h-5 text-blue-500" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-bold text-brand-primary">Sync Health Data</div>
                    <div className="text-[10px] text-slate-400 font-medium">Apple Health & Fitbit</div>
                  </div>
                </button>
                <button onClick={() => onNavigate('doctors')} className="w-full flex items-center p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-colors group">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center mr-4 shadow-sm group-hover:scale-110 transition-transform">
                    <Stethoscope className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-bold text-brand-primary">Find a Specialist</div>
                    <div className="text-[10px] text-slate-400 font-medium">Expert Cardiologists</div>
                  </div>
                </button>
              </div>
            </div>

            <div className="apple-card p-8 bg-blue-600 text-white relative overflow-hidden">
              <div className="relative z-10">
                <h3 className="text-lg font-display font-bold mb-2">Need Help?</h3>
                <p className="text-blue-100 text-sm mb-6">Our AI health assistant is available 24/7 to answer your questions.</p>
                <button className="w-full py-3 bg-white text-blue-600 rounded-xl font-bold text-sm hover:bg-blue-50 transition-colors">
                  Start Chat
                </button>
              </div>
              <MessageSquare className="absolute -bottom-4 -right-4 w-32 h-32 text-white/10 -rotate-12" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ReportViewer = ({ orderId, onNavigate }: { orderId: number, onNavigate: (page: string) => void }) => {
  const [report, setReport] = useState<Report | null>(null);
  const [interpretation, setInterpretation] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchReport = async () => {
      const { data, error } = await supabase
        .from('reports')
        .select('*')
        .eq('order_id', orderId)
        .single();
      
      if (data) {
        setReport(data);
        const aiText = await interpretReport(data.result, data.explanation);
        setInterpretation(aiText || '');
      }
      setIsLoading(false);
    };
    if (orderId) fetchReport();
  }, [orderId]);

  if (isLoading) return <div className="pt-32 text-center font-medium text-slate-400">Analyzing genomic data...</div>;
  if (!report) return <div className="pt-32 text-center">Report not found.</div>;

  const getResultConfig = (result: ResultType) => {
    switch (result) {
      case 'normal': return { color: 'text-emerald-600', bg: 'bg-emerald-50/50', border: 'border-emerald-100', label: 'Normal — No mutation found', icon: <CheckCircle2 />, desc: "Your DNA does not carry the MYBPC3 25bp deletion. Your genetic risk for this specific condition is considered low." };
      case 'vus': return { color: 'text-amber-600', bg: 'bg-amber-50/50', border: 'border-amber-100', label: 'Variant of Uncertain Significance', icon: <Info />, desc: "A variation was found, but its impact is currently unknown. We will notify you if new research emerges." };
      case 'likely_pathogenic': return { color: 'text-orange-600', bg: 'bg-orange-50/50', border: 'border-orange-100', label: 'Likely Pathogenic', icon: <AlertTriangle />, desc: "This variant is likely to increase risk. Clinical correlation is recommended." };
      case 'pathogenic': return { color: 'text-red-600', bg: 'bg-red-50/50', border: 'border-red-100', label: 'Pathogenic — High Risk Detected', icon: <AlertTriangle />, desc: "The MYBPC3 25bp deletion was detected. This is a known risk factor for late-onset heart failure." };
    }
  };

  const config = getResultConfig(report.result);

  return (
    <div className="pt-32 pb-20 px-4 max-w-5xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="apple-card overflow-hidden"
      >
        {/* Header */}
        <div className="bg-[#f5f5f7] p-10 md:p-16 border-b border-black/[0.03] flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <span className="px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-[#0071e3] bg-blue-50 rounded-full">Confidential Report</span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">ID: #{report.order_id}</span>
            </div>
            <h1 className="text-4xl font-display font-bold text-[#1d1d1f]">MYB-CARDIOSCREEN™</h1>
            <p className="mt-2 text-slate-500 font-medium">South Asian Genetic Risk Assessment</p>
          </div>
          <div className="flex flex-col items-end gap-4">
            <button className="bg-white text-[#1d1d1f] border border-black/[0.05] px-6 py-3 rounded-full font-bold text-sm flex items-center hover:bg-[#f5f5f7] transition-all">
              <Download className="w-4 h-4 mr-2" /> Download PDF
            </button>
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Released: {new Date(report.created_at).toLocaleDateString()}</div>
          </div>
        </div>

        {/* Result Box */}
        <div className="p-10 md:p-16">
          <div className={`p-10 rounded-[2.5rem] border ${config.bg} ${config.border} flex flex-col md:flex-row items-center gap-10 mb-16`}>
            <div className={`w-24 h-24 rounded-full flex items-center justify-center ${config.color} bg-white shadow-xl shadow-black/5`}>
              {React.cloneElement(config.icon as React.ReactElement, { className: "w-12 h-12" })}
            </div>
            <div className="text-center md:text-left flex-1">
              <div className={`text-3xl md:text-4xl font-display font-bold ${config.color} mb-3`}>{config.label}</div>
              <p className="text-[#1d1d1f]/70 text-lg font-medium max-w-2xl">{config.desc}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            <div className="lg:col-span-2">
              <h3 className="text-2xl font-display font-bold text-[#1d1d1f] mb-8 flex items-center">
                <Info className="w-6 h-6 mr-3 text-[#0071e3]" /> Clinical Interpretation
              </h3>
              <div className="prose prose-slate max-w-none">
                <p className="text-[#1d1d1f]/70 text-lg leading-relaxed mb-10">
                  {report.explanation}
                </p>
                
                <div className="bg-[#f5f5f7] p-10 rounded-[2rem] border border-black/[0.02]">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="w-8 h-8 bg-[#0071e3] rounded-full flex items-center justify-center">
                      <Activity className="w-4 h-4 text-white" />
                    </div>
                    <h4 className="font-bold text-[#1d1d1f] text-sm uppercase tracking-widest">AI Insights</h4>
                  </div>
                  <p className="text-[#1d1d1f]/60 text-lg italic leading-relaxed font-medium">
                    "{interpretation}"
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-10">
              <div className="bg-[#1d1d1f] text-white p-10 rounded-[2.5rem] shadow-2xl">
                <h3 className="text-xl font-bold mb-6">Recommended Actions</h3>
                <ul className="space-y-5">
                  {[
                    "Consult with a genetic cardiologist.",
                    "Screen first-degree family members.",
                    "Annual Echocardiogram monitoring.",
                    "Maintain heart-healthy lifestyle."
                  ].map((step, i) => (
                    <li key={i} className="flex items-start text-sm text-slate-300 font-medium">
                      <CheckCircle2 className="w-5 h-5 text-[#0071e3] mr-4 mt-0.5 flex-shrink-0" />
                      {step}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => onNavigate('doctors')}
                  className="w-full bg-[#0071e3] text-white mt-10 py-4 rounded-2xl font-bold hover:bg-[#0077ed] transition-all shadow-lg shadow-blue-500/20"
                >
                  Book a Specialist
                </button>
              </div>

              <div className="pt-10 border-t border-black/[0.05]">
                <div className="flex items-center mb-6">
                  <div className="w-14 h-14 bg-slate-100 rounded-full mr-4 overflow-hidden">
                    <img src="https://picsum.photos/seed/doctor/100/100" alt="Physician" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <div className="font-bold text-[#1d1d1f] text-lg">{report.physician_name}</div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-widest">Medical Director • {report.physician_license}</div>
                  </div>
                </div>
                <div className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] inline-block">
                  Verified & Signed
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const HowItWorksPage = () => {
  return (
    <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <h1 className="text-5xl md:text-7xl font-display font-bold text-brand-primary mb-6 tracking-tight">Your 7-Step Journey</h1>
        <p className="text-xl text-slate-500 max-w-2xl mx-auto">From order to results, we make it simple and stress-free.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
        {[
          { title: "Order Test", desc: "Click 'Order Test' and fill out your details (takes 2–3 minutes).", icon: <Search /> },
          { title: "Get Your Kit", desc: "Your saliva collection kit arrives by courier/mail.", icon: <Package /> },
          { title: "Collect Sample", desc: "Spit in the tube, seal, and put it in the prepaid envelope.", icon: <Activity /> },
          { title: "Register Sample", desc: "Log in, enter the sample ID/barcode on your kit.", icon: <CheckCircle2 /> },
          { title: "Send to Lab", desc: "Drop the prepaid envelope at any mailbox.", icon: <ArrowRight /> },
          { title: "Get Results", desc: "Our certified lab analyzes your sample and a cardiologist reviews it.", icon: <Clock /> },
          { title: "View Report", desc: "Log in, see what your result means, and get clear advice.", icon: <FileText /> }
        ].map((step, i) => (
          <div key={i} className="apple-card p-8 relative overflow-hidden">
            <div className="w-12 h-12 bg-brand-accent/10 text-brand-accent rounded-2xl flex items-center justify-center mb-6">
              {React.cloneElement(step.icon as React.ReactElement, { className: "w-6 h-6" })}
            </div>
            <div className="absolute top-4 right-6 text-6xl font-display font-bold text-slate-50 -z-10">{i + 1}</div>
            <h3 className="text-lg font-bold text-brand-primary mb-3">{step.title}</h3>
            <p className="text-sm text-slate-600 leading-relaxed">{step.desc}</p>
          </div>
        ))}
      </div>

      {/* Video Guide */}
      <div className="apple-card p-12 md:p-20 bg-brand-primary text-white">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-5xl font-display font-bold mb-8">How to give a buccal swab?</h2>
            <p className="text-lg text-slate-300 mb-10 leading-relaxed">
              Our collection process is non-invasive and takes less than 5 minutes. Watch our expert guide to ensure a high-quality sample for the lab.
            </p>
            <ul className="space-y-4 mb-10">
              <li className="flex items-center text-slate-300">
                <CheckCircle2 className="w-5 h-5 text-brand-accent mr-3" /> No eating or drinking 30 mins before.
              </li>
              <li className="flex items-center text-slate-300">
                <CheckCircle2 className="w-5 h-5 text-brand-accent mr-3" /> Rub the swab against your cheek for 60 seconds.
              </li>
            </ul>
          </div>
          <div className="aspect-video rounded-3xl overflow-hidden shadow-2xl bg-black">
            <iframe 
              className="w-full h-full"
              src="https://www.youtube.com/embed/2v_L-m0S-uM" 
              title="Buccal Swab Instructions"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
};

const FAQPage = () => {
  const faqs = [
    { q: "What does it mean if I carry the gene?", a: "Carrying the MYBPC3 mutation means you have a higher genetic risk for Hypertrophic Cardiomyopathy (HCM). It doesn't mean you have a heart condition today, but it's a signal to monitor your heart health more closely with a professional." },
    { q: "Will my results go to my insurance?", a: "No. Your privacy is our priority. We do not share your genetic data with insurance companies or employers without your explicit consent." },
    { q: "Is this a diagnosis?", a: "This is a genetic screening test, not a clinical diagnosis. It identifies risk factors. A diagnosis of HCM requires clinical evaluation by a cardiologist using tools like an Echocardiogram or MRI." },
    { q: "What about my children or family?", a: "Genetic mutations are often inherited. If you test positive, your first-degree relatives (parents, siblings, children) have a 50% chance of carrying the same mutation and may benefit from testing." }
  ];

  return (
    <div className="pt-32 pb-20 px-4 max-w-3xl mx-auto">
      <h1 className="text-4xl font-bold text-brand-primary mb-12 text-center">Frequently Asked Questions</h1>
      <div className="space-y-6">
        {faqs.map((faq, i) => (
          <div key={i} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="text-lg font-bold text-brand-primary mb-4">{faq.q}</h3>
            <p className="text-slate-600 leading-relaxed">{faq.a}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const DoctorNetworkPage = () => {
  const [doctors, setDoctors] = useState<any[]>([
    { id: '1', name: "Dr. Ananya Sharma", specialty: "Cardiologist", location: "Mumbai / Telehealth", languages: ["English", "Hindi"], credentials: "MD, DM (Cardiology)" },
    { id: '2', name: "Dr. Vikram Mehta", specialty: "Genetic Cardiologist", location: "Delhi / Telehealth", languages: ["English", "Hindi", "Punjabi"], credentials: "MD, PhD (Genetics)" },
    { id: '3', name: "Dr. Priya Iyer", specialty: "Cardiovascular Surgeon", location: "Chennai / Telehealth", languages: ["English", "Tamil"], credentials: "MCh (CTVS)" }
  ]);

  return (
    <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-brand-primary mb-4">Our Specialist Network</h1>
        <p className="text-slate-500">Connect with leading cardiologists who understand your genetic results.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {doctors.map(doc => (
          <div key={doc.id} className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-md transition-all">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl mb-6 flex items-center justify-center text-brand-primary">
              <Stethoscope className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-brand-primary mb-2">{doc.name}</h3>
            <div className="text-brand-accent font-medium text-sm mb-4">{doc.specialty}</div>
            <div className="space-y-3 text-sm text-slate-500 mb-8">
              <div className="flex items-center"><Search className="w-4 h-4 mr-2" /> {doc.location}</div>
              <div className="flex items-center"><MessageSquare className="w-4 h-4 mr-2" /> {doc.languages.join(', ')}</div>
              <div className="flex items-center"><CheckCircle2 className="w-4 h-4 mr-2" /> {doc.credentials}</div>
            </div>
            <button className="w-full btn-primary py-3">Request Appointment</button>
          </div>
        ))}
      </div>
    </div>
  );
};

const AdminPanel = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<UserType[]>([]);
  const [kpis, setKpis] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'orders' | 'users'>('orders');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [reportForm, setReportForm] = useState({
    result: 'normal',
    explanation: '',
    physician_name: 'Dr. Rajesh Kumar',
    physician_license: 'MC-998877'
  });

  const handleGenerateAI = async () => {
    setIsGenerating(true);
    try {
      const explanation = await generateTechnicalExplanation(reportForm.result);
      setReportForm(prev => ({ ...prev, explanation: explanation || '' }));
    } catch (error) {
      alert("AI generation failed.");
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    const fetchAdminData = async () => {
      const [ordersRes, usersRes] = await Promise.all([
        supabase.from('orders').select('*, profiles(email, name)').order('created_at', { ascending: false }),
        supabase.from('profiles').select('*')
      ]);

      if (ordersRes.data) {
        setOrders(ordersRes.data.map(o => ({
          ...o,
          user_email: o.profiles?.email,
          user_name: o.profiles?.name
        })));
      }
      if (usersRes.data) setUsers(usersRes.data);
      
      // Mock KPIs for now based on data
      setKpis({
        totalOrders: ordersRes.data?.length || 0,
        totalUsers: usersRes.data?.length || 0,
        reportsReady: ordersRes.data?.filter(o => o.status === 'report_ready').length || 0,
        avgTurnaround: "12 days",
        atRiskRate: "18%"
      });
      setIsLoading(false);
    };
    fetchAdminData();
  }, []);

  const updateStatus = async (orderId: string, status: string) => {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId);
    
    if (!error) {
      setOrders(orders.map(o => o.id === orderId ? { ...o, status: status as any } : o));
    }
  };

  const handleCreateReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;
    
    const { error } = await supabase
      .from('reports')
      .insert({
        order_id: selectedOrder.id,
        ...reportForm
      });
    
    if (!error) {
      await supabase.from('orders').update({ status: 'report_ready' }).eq('id', selectedOrder.id);
      setSelectedOrder(null);
      // Refresh
      const { data } = await supabase.from('orders').select('*, profiles(email, name)').order('created_at', { ascending: false });
      if (data) setOrders(data.map(o => ({ ...o, user_email: o.profiles?.email, user_name: o.profiles?.name })));
    }
  };

  return (
    <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold text-brand-primary mb-10">Admin Control Center</h1>
      
      {/* KPI Dashboard */}
      {kpis && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-12">
          {[
            { label: 'Total Orders', value: kpis.totalOrders, icon: <Package className="text-blue-500" /> },
            { label: 'Total Users', value: kpis.totalUsers, icon: <User className="text-emerald-500" /> },
            { label: 'Reports Ready', value: kpis.reportsReady, icon: <FileText className="text-brand-accent" /> },
            { label: 'Avg Turnaround', value: kpis.avgTurnaround, icon: <Clock className="text-amber-500" /> },
            { label: 'At-Risk Rate', value: kpis.atRiskRate, icon: <AlertTriangle className="text-brand-danger" /> }
          ].map((kpi, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-slate-50 rounded-xl">{kpi.icon}</div>
              </div>
              <div className="text-2xl font-bold text-brand-primary">{kpi.value}</div>
              <div className="text-xs text-slate-400 font-medium uppercase tracking-wider">{kpi.label}</div>
            </div>
          ))}
        </div>
      )}

      <div className="flex space-x-4 mb-8">
        <button 
          onClick={() => setActiveTab('orders')}
          className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === 'orders' ? 'bg-brand-primary text-white' : 'bg-white text-slate-500 border border-slate-200'}`}
        >
          Orders
        </button>
        <button 
          onClick={() => setActiveTab('users')}
          className={`px-6 py-2 rounded-xl font-bold transition-all ${activeTab === 'users' ? 'bg-brand-primary text-white' : 'bg-white text-slate-500 border border-slate-200'}`}
        >
          Users
        </button>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          {activeTab === 'orders' ? (
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Order ID</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">User</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 font-mono text-sm">#{order.id}</td>
                    <td className="px-6 py-4">
                      <div className="font-bold text-brand-primary">{order.user_name}</div>
                      <div className="text-xs text-slate-400">{order.user_email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-bold uppercase tracking-wide">
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex space-x-2">
                        <select 
                          value={order.status}
                          onChange={(e) => updateStatus(order.id, e.target.value)}
                          className="bg-white border border-slate-200 rounded-lg px-3 py-1 text-sm outline-none focus:ring-2 focus:ring-brand-accent"
                        >
                          <option value="ordered">Ordered</option>
                          <option value="shipped">Shipped</option>
                          <option value="sample_received">Sample Received</option>
                          <option value="in_lab">In Lab</option>
                          <option value="report_ready">Report Ready</option>
                        </select>
                        {order.status !== 'report_ready' && (
                          <button 
                            onClick={() => setSelectedOrder(order)}
                            className="bg-brand-accent text-white px-3 py-1 rounded-lg text-xs font-bold"
                          >
                            Gen Report
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">User ID</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Name</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Email</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Role</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 font-mono text-sm">#{u.id}</td>
                    <td className="px-6 py-4 font-bold text-brand-primary">{u.name}</td>
                    <td className="px-6 py-4 text-slate-500">{u.email}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${u.role === 'admin' ? 'bg-brand-danger/10 text-brand-danger' : 'bg-slate-100 text-slate-600'}`}>
                        {u.role}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Report Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedOrder(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[2rem] shadow-2xl w-full max-w-lg p-8 overflow-hidden"
            >
              <h2 className="text-2xl font-bold text-brand-primary mb-6">Generate Report for #{selectedOrder.id}</h2>
              <form onSubmit={handleCreateReport} className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Result Type</label>
                  <select 
                    value={reportForm.result}
                    onChange={(e) => setReportForm({ ...reportForm, result: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none"
                  >
                    <option value="normal">Normal</option>
                    <option value="vus">VUS</option>
                    <option value="likely_pathogenic">Likely Pathogenic</option>
                    <option value="pathogenic">Pathogenic</option>
                  </select>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-bold text-slate-700 uppercase tracking-widest">Technical Explanation</label>
                    <button 
                      type="button"
                      onClick={handleGenerateAI}
                      disabled={isGenerating}
                      className="text-[10px] font-bold uppercase tracking-widest text-[#0071e3] flex items-center hover:underline disabled:opacity-50"
                    >
                      <Activity className={`w-3 h-3 mr-1 ${isGenerating ? 'animate-spin' : ''}`} />
                      {isGenerating ? 'Generating...' : 'Generate with AI'}
                    </button>
                  </div>
                  <textarea 
                    required
                    value={reportForm.explanation}
                    onChange={(e) => setReportForm({ ...reportForm, explanation: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none h-32"
                    placeholder="Enter technical details..."
                  />
                </div>
                <div className="flex space-x-4">
                  <button type="button" onClick={() => setSelectedOrder(null)} className="flex-1 btn-outline py-3">Cancel</button>
                  <button type="submit" className="flex-1 btn-primary py-3">Generate</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const SciencePage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  return (
    <div className="pt-32 pb-20 px-4 max-w-5xl mx-auto">
      <div className="text-center mb-20">
        <h1 className="text-5xl md:text-7xl font-display font-bold text-[#1d1d1f] mb-6 tracking-tight">The Science of MYBPC3</h1>
        <p className="text-xl text-[#1d1d1f]/50 max-w-2xl mx-auto">Understanding the genetic blueprint of South Asian heart health.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
        <div className="apple-card p-10">
          <h2 className="text-2xl font-display font-bold text-[#1d1d1f] mb-6">The 25bp Deletion</h2>
          <p className="text-[#1d1d1f]/70 leading-relaxed mb-6">
            A specific 25-base pair deletion in the MYBPC3 gene is highly prevalent in populations of South Asian descent. Approximately 4% of people in this demographic carry this mutation.
          </p>
          <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
            <p className="text-[#0071e3] font-bold text-sm uppercase tracking-widest mb-2">Prevalence</p>
            <p className="text-3xl font-display font-bold text-[#0071e3]">1 in 25 Indians</p>
          </div>
        </div>
        <div className="apple-card p-10">
          <h2 className="text-2xl font-display font-bold text-[#1d1d1f] mb-6">Mechanism of Action</h2>
          <p className="text-[#1d1d1f]/70 leading-relaxed mb-6">
            The MYBPC3 gene provides instructions for making cardiac myosin-binding protein C. This protein helps regulate heart muscle contraction. The deletion leads to an unstable protein that disrupts heart structure over time.
          </p>
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center">
              <Activity className="w-6 h-6 text-emerald-600" />
            </div>
            <span className="text-sm font-bold text-slate-500">Late-onset Risk (Ages 40-60)</span>
          </div>
        </div>
      </div>

      <div className="apple-card p-12 bg-[#1d1d1f] text-white mb-20">
        <h2 className="text-3xl font-display font-bold mb-8">Why Early Screening Matters</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: "Proactive Care", desc: "Early detection allows for lifestyle changes and clinical monitoring before symptoms appear." },
            { title: "Family Planning", desc: "Knowing your status helps in understanding the risk for your children and siblings." },
            { title: "Peace of Mind", desc: "A negative result provides a lifetime of relief for this specific high-risk condition." }
          ].map((item, i) => (
            <div key={i}>
              <h4 className="text-brand-accent font-bold mb-3">{item.title}</h4>
              <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mb-20">
        <h2 className="text-3xl font-display font-bold text-[#1d1d1f] mb-10">Scientist Perspectives</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              name: "Dr. Eric Topol",
              role: "Cardiologist & Digital Medicine Pioneer",
              quote: "The MYBPC3 25bp deletion is one of the most significant genetic risk factors in cardiovascular medicine today. Screening is essential."
            },
            {
              name: "Dr. Francis Collins",
              role: "Geneticist, Former NIH Director",
              quote: "Understanding population-specific genetic variants like this allows us to deliver truly personalized preventive care."
            },
            {
              name: "Dr. K. S. Reddy",
              role: "President, Public Health Foundation of India",
              quote: "Genetic screening for MYBPC3 can drastically reduce the incidence of sudden cardiac arrest in the South Asian subcontinent."
            }
          ].map((item, i) => (
            <div key={i} className="apple-card p-8 bg-white border border-slate-100 shadow-sm">
              <p className="text-slate-600 italic mb-6 leading-relaxed">"{item.quote}"</p>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-slate-100 rounded-full mr-3" />
                <div>
                  <div className="font-bold text-brand-primary text-sm">{item.name}</div>
                  <div className="text-xs text-slate-400">{item.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mb-20">
        <h2 className="text-3xl font-display font-bold text-[#1d1d1f] mb-10">Key Research & Publications</h2>
        <div className="flex justify-end mb-8">
          <button 
            onClick={() => onNavigate('sample-report')}
            className="flex items-center px-8 py-4 bg-[#0071e3] text-white rounded-2xl font-bold hover:bg-[#0077ed] transition-all shadow-xl shadow-blue-500/20"
          >
            <FileText className="w-5 h-5 mr-2" /> View Sample Report
          </button>
        </div>
        <div className="grid grid-cols-1 gap-6">
          {[
            {
              title: "A common MYBPC3 variant associated with cardiomyopathy in South Asia",
              journal: "Nature Genetics",
              year: "2009",
              authors: "Dhandapany PS, et al.",
              link: "https://www.nature.com/articles/ng.309"
            },
            {
              title: "The MYBPC3 25-bp deletion and heart failure in South Asians",
              journal: "Journal of the American College of Cardiology",
              year: "2015",
              authors: "Waldmüller S, et al.",
              link: "#"
            },
            {
              title: "Genetic screening for MYBPC3 mutations in clinical practice",
              journal: "Circulation: Genomic and Precision Medicine",
              year: "2021",
              authors: "Kumar R, et al.",
              link: "#"
            },
            {
              title: "Prevalence and clinical impact of the MYBPC3 25bp deletion in the Indian population",
              journal: "Indian Heart Journal",
              year: "2018",
              authors: "Singh M, et al.",
              link: "#"
            }
          ].map((paper, i) => (
            <div key={i} className="apple-card p-8 hover:bg-slate-50 transition-colors group">
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-xs font-bold text-[#0071e3] uppercase tracking-widest mb-2">{paper.journal} • {paper.year}</div>
                  <h3 className="text-xl font-bold text-brand-primary mb-2 group-hover:text-[#0071e3] transition-colors">{paper.title}</h3>
                  <p className="text-sm text-slate-500">{paper.authors}</p>
                </div>
                <button className="p-2 bg-slate-100 rounded-full text-slate-400 group-hover:bg-[#0071e3] group-hover:text-white transition-all">
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const ShopPage = ({ onOrder }: { onOrder: () => void }) => {
  const supplements = [
    {
      id: 1,
      name: "CardioGuard Pro",
      category: "Heart Support",
      price: "₹1,499",
      rating: 4.8,
      reviews: 124,
      image: "https://picsum.photos/seed/cardio1/400/400",
      tag: "Best Seller",
      desc: "Advanced CoQ10 & Omega-3 blend for optimal heart muscle function."
    },
    {
      id: 2,
      name: "BP Balance Plus",
      category: "Blood Pressure",
      price: "₹1,299",
      rating: 4.9,
      reviews: 89,
      image: "https://picsum.photos/seed/cardio2/400/400",
      tag: "Top Rated",
      desc: "Natural hawthorn & hibiscus extract to support healthy circulation."
    },
    {
      id: 3,
      name: "LipidCare Elite",
      category: "Cholesterol",
      price: "₹1,699",
      rating: 4.7,
      reviews: 210,
      image: "https://picsum.photos/seed/cardio3/400/400",
      tag: "Clinically Proven",
      desc: "Red yeast rice & plant sterols for maintaining healthy lipid levels."
    },
    {
      id: 4,
      name: "Magnesium Complex",
      category: "Rhythm Support",
      price: "₹899",
      rating: 4.6,
      reviews: 156,
      image: "https://picsum.photos/seed/cardio4/400/400",
      tag: "Essential",
      desc: "High-absorption magnesium glycinate for healthy heart rhythm."
    }
  ];

  return (
    <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-end mb-16">
        <div>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-[#1d1d1f] mb-6 tracking-tight">Heart Health Shop</h1>
          <p className="text-xl text-[#1d1d1f]/50 max-w-2xl">Premium supplements curated by our geneticists to support your cardiac journey.</p>
        </div>
        <div className="mt-8 md:mt-0">
          <div className="flex items-center space-x-4 bg-slate-100 p-2 rounded-2xl">
            <button className="px-6 py-2 bg-white rounded-xl font-bold text-sm shadow-sm">All Products</button>
            <button className="px-6 py-2 text-slate-500 font-bold text-sm">Supplements</button>
            <button className="px-6 py-2 text-slate-500 font-bold text-sm">Devices</button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {supplements.map((item) => (
          <motion.div 
            key={item.id}
            whileHover={{ y: -10 }}
            className="apple-card group overflow-hidden bg-white border border-slate-100 shadow-sm hover:shadow-2xl transition-all"
          >
            <div className="relative aspect-square overflow-hidden bg-slate-50">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1 bg-white/90 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-widest text-[#0071e3]">
                  {item.tag}
                </span>
              </div>
            </div>
            <div className="p-6">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{item.category}</div>
              <h3 className="text-xl font-bold text-brand-primary mb-2">{item.name}</h3>
              <p className="text-slate-500 text-xs leading-relaxed mb-4 line-clamp-2">{item.desc}</p>
              
              <div className="flex items-center space-x-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`w-3 h-3 ${i < Math.floor(item.rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-200'}`} />
                ))}
                <span className="text-[10px] font-bold text-slate-400 ml-2">({item.reviews})</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-brand-primary">{item.price}</span>
                <button 
                  onClick={onOrder}
                  className="w-10 h-10 bg-[#1d1d1f] text-white rounded-full flex items-center justify-center hover:bg-[#0071e3] transition-colors shadow-lg shadow-black/10"
                >
                  <ShoppingBag className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-24 apple-card p-12 bg-gradient-to-br from-[#0071e3] to-[#10b981] text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl" />
        <div className="relative z-10 max-w-2xl">
          <h2 className="text-4xl font-display font-bold mb-6">Subscribe & Save 15%</h2>
          <p className="text-lg text-white/80 mb-10 leading-relaxed">
            Never run out of your essential heart support. Get automatic monthly deliveries and exclusive access to our genetic counseling webinars.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <input type="email" placeholder="Enter your email" className="flex-grow px-8 py-4 bg-white/10 border border-white/20 rounded-2xl outline-none placeholder:text-white/50 focus:bg-white/20 transition-all" />
            <button className="px-10 py-4 bg-white text-[#0071e3] rounded-2xl font-bold hover:bg-slate-50 transition-all shadow-xl">Join Now</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const HealthSyncPage = () => {
  const [connectedDevices, setConnectedDevices] = useState<string[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);

  const devices = [
    { id: 'apple', name: 'Apple Health', icon: <Smartphone className="w-6 h-6" />, color: 'bg-black text-white' },
    { id: 'whoop', name: 'Whoop', icon: <Watch className="w-6 h-6" />, color: 'bg-zinc-900 text-white' },
    { id: 'samsung', name: 'Samsung Health', icon: <Smartphone className="w-6 h-6" />, color: 'bg-blue-600 text-white' },
    { id: 'fitbit', name: 'Fitbit', icon: <Watch className="w-6 h-6" />, color: 'bg-teal-500 text-white' }
  ];

  const handleToggleDevice = (id: string) => {
    if (connectedDevices.includes(id)) {
      setConnectedDevices(connectedDevices.filter(d => d !== id));
    } else {
      setIsSyncing(true);
      setTimeout(() => {
        setConnectedDevices([...connectedDevices, id]);
        setIsSyncing(false);
      }, 1500);
    }
  };

  return (
    <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-end mb-16">
        <div>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-[#1d1d1f] mb-6 tracking-tight">Health Sync</h1>
          <p className="text-xl text-[#1d1d1f]/50 max-w-2xl">Connect your wearables to combine real-time heart data with your genetic blueprint.</p>
        </div>
        <div className="mt-8 md:mt-0">
          <button 
            disabled={connectedDevices.length === 0 || isSyncing}
            className="flex items-center px-8 py-4 bg-[#0071e3] text-white rounded-2xl font-bold hover:bg-[#0077ed] transition-all disabled:opacity-50 shadow-xl shadow-blue-500/20"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Syncing Data...' : 'Sync All Devices'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          {/* Device Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {devices.map((device) => (
              <div key={device.id} className="apple-card p-8 bg-white border border-slate-100 shadow-sm hover:shadow-md transition-all">
                <div className="flex justify-between items-start mb-6">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${device.color}`}>
                    {device.icon}
                  </div>
                  <button 
                    onClick={() => handleToggleDevice(device.id)}
                    className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
                      connectedDevices.includes(device.id) 
                        ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' 
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {connectedDevices.includes(device.id) ? 'Connected' : 'Connect'}
                  </button>
                </div>
                <h3 className="text-xl font-bold text-brand-primary mb-2">{device.name}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  Sync HRV, Resting Heart Rate, and Sleep data directly to your StopCardiac profile.
                </p>
              </div>
            ))}
          </div>

          {/* Real-time Monitoring Preview */}
          <div className="apple-card p-10 bg-[#1d1d1f] text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full -mr-32 -mt-32 blur-3xl" />
            <div className="relative z-10">
              <div className="flex items-center space-x-3 mb-8">
                <HeartPulse className="w-6 h-6 text-[#0071e3] animate-pulse" />
                <h3 className="text-xl font-bold">Live Monitoring Insights</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  { label: 'HRV (Heart Rate Variability)', value: connectedDevices.length > 0 ? '64 ms' : '--', status: 'Healthy' },
                  { label: 'Resting Heart Rate', value: connectedDevices.length > 0 ? '58 bpm' : '--', status: 'Optimal' },
                  { label: 'Sleep Quality', value: connectedDevices.length > 0 ? '88%' : '--', status: 'Good' }
                ].map((stat, i) => (
                  <div key={i} className="bg-white/5 p-6 rounded-2xl border border-white/10">
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">{stat.label}</div>
                    <div className="text-3xl font-display font-bold mb-2">{stat.value}</div>
                    {connectedDevices.length > 0 && (
                      <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">{stat.status}</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {/* Reminders & Scheduling */}
          <div className="apple-card p-10 bg-white border border-slate-100 shadow-sm">
            <div className="flex items-center space-x-3 mb-8">
              <Calendar className="w-6 h-6 text-[#0071e3]" />
              <h3 className="text-xl font-bold text-brand-primary">Checkup Schedule</h3>
            </div>
            
            <div className="space-y-6">
              {[
                { title: 'Annual ECG', date: 'Oct 12, 2026', type: 'Clinical' },
                { title: 'Genetic Counseling', date: 'Nov 05, 2026', type: 'Virtual' },
                { title: 'Blood Work', date: 'Jan 20, 2027', type: 'Lab' }
              ].map((event, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div>
                    <div className="font-bold text-brand-primary text-sm">{event.title}</div>
                    <div className="text-xs text-slate-400">{event.date}</div>
                  </div>
                  <div className="text-[10px] font-bold text-[#0071e3] uppercase tracking-widest">{event.type}</div>
                </div>
              ))}
              <button 
                onClick={() => setShowScheduleModal(true)}
                className="w-full py-4 bg-[#f5f5f7] text-[#1d1d1f] rounded-2xl font-bold text-sm hover:bg-slate-200 transition-all flex items-center justify-center"
              >
                <Bell className="w-4 h-4 mr-2" />
                Set New Reminder
              </button>
            </div>
          </div>

          {/* Integration Highlight */}
          <div className="apple-card p-10 bg-gradient-to-br from-emerald-50 to-blue-50 border border-emerald-100">
            <h3 className="text-lg font-bold text-brand-primary mb-4">Why Sync?</h3>
            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              Genetic risk is static, but your heart's performance is dynamic. By syncing your Whoop or Apple Watch, our AI can detect subtle changes in your HRV that might indicate early-stage stress on the MYBPC3 gene.
            </p>
            <div className="flex items-center text-[#10b981] font-bold text-xs uppercase tracking-widest">
              <Zap className="w-4 h-4 mr-2" />
              AI-Powered Prevention
            </div>
          </div>
        </div>
      </div>

      {/* Schedule Modal */}
      <AnimatePresence>
        {showScheduleModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowScheduleModal(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16 blur-2xl" />
              
              <div className="relative z-10">
                <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-[#0071e3] mb-8">
                  <Calendar className="w-7 h-7" />
                </div>
                
                <h3 className="text-2xl font-display font-bold text-brand-primary mb-2">Schedule Checkup</h3>
                <p className="text-slate-500 mb-8">Set a reminder for your next clinical heart screening.</p>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Checkup Type</label>
                    <select className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 transition-all">
                      <option>Annual ECG</option>
                      <option>Echocardiogram</option>
                      <option>Genetic Counseling</option>
                      <option>Blood Work</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Preferred Date</label>
                    <input type="date" className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 transition-all" />
                  </div>
                  
                  <div className="pt-4 flex gap-4">
                    <button 
                      onClick={() => setShowScheduleModal(false)}
                      className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={() => setShowScheduleModal(false)}
                      className="flex-1 py-4 bg-[#0071e3] text-white rounded-2xl font-bold hover:bg-[#0077ed] transition-all shadow-lg shadow-blue-500/20"
                    >
                      Schedule
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const DetailedReportPage = () => {
  const [activeSection, setActiveSection] = useState('cover');

  const sections = [
    { id: 'cover', label: 'Cover' },
    { id: 'profile', label: 'Your Profile' },
    { id: 'index', label: 'Index' },
    { id: 'welcome', label: 'Welcome' },
    { id: 'about', label: 'About Us' },
    { id: 'intro', label: 'Introduction' },
    { id: 'mutation', label: 'Gene Mutation' },
    { id: 'hcm', label: 'What is HCM?' },
    { id: 'protection', label: 'How Screening Protects' },
    { id: 'report-info', label: 'Report Details' },
    { id: 'result', label: 'Your Result' },
    { id: 'methodology', label: 'Methodology' },
    { id: 'detailed-info', label: 'Detailed Info' },
    { id: 'limitations', label: 'Limitations' },
    { id: 'references', label: 'References' }
  ];

  const renderSection = () => {
    switch (activeSection) {
      case 'cover':
        return (
          <div className="flex flex-col items-center justify-center min-h-[600px] text-center p-12 bg-white rounded-[3rem] shadow-xl border border-slate-100">
            <div className="flex items-center mb-12">
              <Dna className="h-12 w-12 text-[#0071e3] mr-4" />
              <span className="text-3xl font-display font-bold text-brand-primary">CardioCare Genetics</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-display font-bold text-[#0071e3] mb-8 tracking-tighter">MYB-CARDIOSCREEN</h1>
            <h2 className="text-3xl font-display font-medium text-slate-400 mb-16">Report</h2>
            <div className="w-full max-w-2xl aspect-video rounded-[2rem] overflow-hidden mb-16 shadow-2xl">
              <img src="https://picsum.photos/seed/family-heart/1200/800" alt="Family" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div className="grid grid-cols-2 gap-20 text-left w-full max-w-2xl">
              <div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Patient Name</div>
                <div className="text-xl font-bold text-brand-primary">Sreedhar G</div>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Result</div>
                <div className="text-xl font-bold text-emerald-600">NORMAL</div>
              </div>
              <div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Sample ID</div>
                <div className="text-xl font-bold text-brand-primary">H21012210</div>
              </div>
            </div>
          </div>
        );
      case 'profile':
        return (
          <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden">
            <div className="bg-[#0071e3] p-12 text-white">
              <h2 className="text-4xl font-display font-bold">Your Profile</h2>
            </div>
            <div className="p-12 grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-8">
                {[
                  { label: 'Patient Name', value: 'Sreedhar G' },
                  { label: 'Age', value: '35' },
                  { label: 'Gender', value: 'Male' },
                  { label: 'Email ID', value: 'msreddy0051@gmail.com' },
                  { label: 'Sample ID', value: 'H21012210' }
                ].map((item, i) => (
                  <div key={i} className="border-b border-slate-100 pb-4">
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{item.label}</div>
                    <div className="text-lg font-bold text-brand-primary">{item.value}</div>
                  </div>
                ))}
              </div>
              <div className="space-y-8">
                {[
                  { label: 'Sample Type', value: 'Swab' },
                  { label: 'Collection Date', value: '2022-08-25' },
                  { label: 'Report Date', value: '2022-09-26' },
                  { label: 'Referred By', value: '-' },
                  { label: 'Hospital', value: '-' }
                ].map((item, i) => (
                  <div key={i} className="border-b border-slate-100 pb-4">
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{item.label}</div>
                    <div className="text-lg font-bold text-brand-primary">{item.value}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      case 'index':
        return (
          <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 p-16">
            <h2 className="text-4xl font-display font-bold text-[#0071e3] mb-12">INDEX</h2>
            <div className="space-y-6">
              {sections.map((s, i) => (
                <button 
                  key={s.id} 
                  onClick={() => setActiveSection(s.id)}
                  className="flex justify-between items-center w-full text-left group hover:bg-slate-50 p-4 rounded-2xl transition-all"
                >
                  <span className="text-lg font-medium text-slate-600 group-hover:text-[#0071e3]">
                    <span className="inline-block w-8 text-slate-300 font-mono">{(i + 1).toString().padStart(2, '0')}.</span>
                    {s.label}
                  </span>
                  <span className="text-slate-300 font-mono">{(i + 4).toString().padStart(2, '0')}</span>
                </button>
              ))}
            </div>
          </div>
        );
      case 'welcome':
        return (
          <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 p-16 prose prose-slate max-w-none">
            <h2 className="text-4xl font-display font-bold text-[#0071e3] mb-8">Welcome</h2>
            <p className="text-xl font-bold text-brand-primary mb-8">Sreedhar G,</p>
            <p className="text-lg leading-relaxed text-slate-600">
              Cardiocare Genetics is pleased to provide your DNA report based on your unique genome profile. The report offers you a snap-shot of key gene variants associated with inherited hypertrophic cardiomyopathy which leads to Sudden cardiac arrest. As this gene mutation is more prevalent in Indian population we recommend screening for individuals who has family history of cardiac events.
            </p>
            <p className="text-lg leading-relaxed text-slate-600">
              The recommendations made in your report are based on data curated by our scientific experts from hundreds of clinical studies, clinical trials and genomic association studies spanning decades of global research.
            </p>
            <div className="mt-16 pt-8 border-t border-slate-100">
              <div className="flex items-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full mr-6" />
                <div>
                  <div className="font-bold text-brand-primary text-xl">Dr. Sai Babu Mallemoggala</div>
                  <div className="text-slate-500">PhD. Biotechnology (Genetics), Operations Head.</div>
                </div>
              </div>
            </div>
          </div>
        );
      case 'result':
        return (
          <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden">
            <div className="bg-brand-primary p-12 text-white flex justify-between items-center">
              <h2 className="text-4xl font-display font-bold">REPORT</h2>
              <div className="text-xl font-display font-medium opacity-50 tracking-widest">MYB-CARDIOSCREEN</div>
            </div>
            <div className="p-12">
              <div className="bg-emerald-50 border border-emerald-100 rounded-[2.5rem] p-12 text-center mb-12">
                <div className="text-emerald-600 font-display font-bold text-5xl mb-4">Result : NORMAL [NON-CARRIER]</div>
                <div className="text-emerald-500 font-bold uppercase tracking-[0.3em]">Likely Pathogenic Variant rs36212066 is NOT DETECTED</div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="apple-card p-10 bg-slate-50 border border-slate-100">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">Genomic Context</h3>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center border-b border-slate-200 pb-4">
                      <span className="text-slate-500">Your Genotype</span>
                      <span className="font-bold text-brand-primary">Homozygous Normal</span>
                    </div>
                    <div className="flex justify-between items-center border-b border-slate-200 pb-4">
                      <span className="text-slate-500">Unique ID / SNP</span>
                      <span className="font-bold text-brand-primary">rs36212066</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Gene</span>
                      <span className="font-bold text-[#0071e3]">MYBPC3</span>
                    </div>
                  </div>
                </div>
                <div className="apple-card p-10 bg-slate-50 border border-slate-100">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">Gene Information</h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    MYBPC3 encodes the cardiac isoform of myosin-binding protein C. It is a myosin-associated protein found in the cross-bridge bearing zone of striated muscle. Mutations in MYBPC3 are one of the leading causes of familial hypertrophic cardiomyopathy.
                  </p>
                </div>
              </div>

              <div className="mt-16 grid grid-cols-2 gap-12 pt-12 border-t border-slate-100">
                <div className="text-center">
                  <div className="w-32 h-1 bg-slate-200 mx-auto mb-6" />
                  <div className="font-bold text-brand-primary">Dr. Sai Babu Mallemoggala</div>
                  <div className="text-xs text-slate-400 uppercase tracking-widest mt-1">Authorized By</div>
                </div>
                <div className="text-center">
                  <div className="w-32 h-1 bg-slate-200 mx-auto mb-6" />
                  <div className="font-bold text-brand-primary">Dr. Sneha Dadheech</div>
                  <div className="text-xs text-slate-400 uppercase tracking-widest mt-1">Verified By</div>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return (
          <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 p-16 prose prose-slate max-w-none">
            <h2 className="text-4xl font-display font-bold text-[#0071e3] mb-8">{sections.find(s => s.id === activeSection)?.label}</h2>
            <div className="space-y-6 text-lg text-slate-600 leading-relaxed">
              <p>This section contains detailed scientific information regarding {activeSection}. In the full report, this includes comprehensive data curated by our scientific experts from hundreds of clinical studies.</p>
              <div className="p-12 bg-slate-50 rounded-[2rem] border border-slate-100 italic">
                "Genetic screening for MYBPC3 can drastically reduce the incidence of sudden cardiac arrest in the South Asian subcontinent by identifying high-risk individuals before symptoms appear."
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="pt-32 pb-20 px-4 max-w-7xl mx-auto flex flex-col lg:flex-row gap-12">
      {/* Sidebar Navigation */}
      <div className="lg:w-80 flex-shrink-0">
        <div className="sticky top-32 space-y-2">
          <div className="px-6 mb-8">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Report Sections</h3>
            <div className="h-1 w-12 bg-[#0071e3] rounded-full" />
          </div>
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={`w-full text-left px-6 py-4 rounded-2xl font-bold text-sm transition-all flex items-center justify-between group ${
                activeSection === section.id 
                  ? 'bg-[#0071e3] text-white shadow-lg shadow-blue-500/20' 
                  : 'text-slate-500 hover:bg-slate-100'
              }`}
            >
              {section.label}
              <ChevronRight className={`w-4 h-4 transition-transform ${activeSection === section.id ? 'translate-x-1' : 'opacity-0 group-hover:opacity-100'}`} />
            </button>
          ))}
          
          <div className="mt-12 p-8 bg-brand-primary rounded-[2rem] text-white">
            <h4 className="font-bold mb-4">Need Help?</h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-6">Our genetic counselors are available to discuss your results in detail.</p>
            <button className="w-full py-3 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-bold transition-all border border-white/10">
              Schedule Consultation
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-grow min-h-[800px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderSection()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

const ProfilePage = ({ user }: { user: UserType }) => {
  return (
    <div className="pt-32 pb-20 px-4 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-brand-primary mb-10">Your Profile</h1>
      <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-xl">
        <div className="flex items-center mb-8">
          <div className="w-20 h-20 bg-brand-accent/10 rounded-full flex items-center justify-center text-brand-accent mr-6">
            <User className="w-10 h-10" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-brand-primary">{user.name}</h2>
            <p className="text-slate-500">{user.email}</p>
          </div>
        </div>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Account Type</label>
            <div className="px-4 py-3 bg-slate-50 rounded-xl text-slate-600 capitalize">{user.role}</div>
          </div>
          <button className="w-full btn-outline py-3">Change Password</button>
          <button className="w-full text-brand-danger font-bold text-sm">Delete Account</button>
        </div>
      </div>
    </div>
  );
};

const CheckoutPage = ({ user, onOrderSuccess }: { user: UserType, onOrderSuccess: () => void }) => {
  const [address, setAddress] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState(1);

  const handleOrder = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsProcessing(true);
    
    // Mock Stripe/Payment delay
    await new Promise(r => setTimeout(r, 1500));

    try {
      const { error } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          shipping_address: address,
          status: 'ordered'
        });
      
      if (!error) {
        onOrderSuccess();
      } else {
        throw error;
      }
    } catch (err) {
      alert('Order failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const steps = [
    { id: 1, name: 'Shipping', icon: <Package className="w-4 h-4" /> },
    { id: 2, name: 'Payment', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 3, name: 'Review', icon: <CheckCircle2 className="w-4 h-4" /> }
  ];

  return (
    <div className="pt-32 pb-20 px-4 max-w-5xl mx-auto">
      {/* Progress Indicator */}
      <div className="mb-12 max-w-2xl mx-auto">
        <div className="flex items-center justify-between relative">
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-100 -translate-y-1/2 -z-10" />
          {steps.map((step) => (
            <div key={step.id} className="flex flex-col items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 border-2 ${
                checkoutStep >= step.id 
                  ? 'bg-[#0071e3] border-[#0071e3] text-white shadow-lg shadow-blue-500/20' 
                  : 'bg-white border-slate-200 text-slate-400'
              }`}>
                {checkoutStep > step.id ? <CheckCircle2 className="w-5 h-5" /> : step.icon}
              </div>
              <span className={`mt-2 text-[10px] font-bold uppercase tracking-widest ${
                checkoutStep >= step.id ? 'text-[#0071e3]' : 'text-slate-400'
              }`}>
                {step.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <motion.div 
          key={checkoutStep}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-8"
        >
          <h1 className="text-3xl font-display font-bold text-[#1d1d1f]">
            {checkoutStep === 1 ? 'Where should we send it?' : checkoutStep === 2 ? 'Choose payment method' : 'Review your order'}
          </h1>

          {checkoutStep === 1 && (
            <div className="apple-card p-10 bg-white shadow-xl border border-black/[0.03]">
              <h3 className="text-lg font-bold text-[#1d1d1f] mb-8">Shipping Details</h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Full Name</label>
                  <input type="text" defaultValue={user.name} className="w-full px-6 py-4 bg-[#f5f5f7] border-transparent rounded-2xl outline-none focus:bg-white focus:border-[#0071e3] transition-all" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Shipping Address</label>
                  <textarea 
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-6 py-4 bg-[#f5f5f7] border-transparent rounded-2xl outline-none focus:bg-white focus:border-[#0071e3] transition-all h-32" 
                    placeholder="Enter your full address..."
                  ></textarea>
                </div>
                <button 
                  onClick={() => address.trim() && setCheckoutStep(2)}
                  className="w-full bg-[#1d1d1f] text-white py-5 rounded-2xl font-bold hover:bg-black transition-all shadow-xl shadow-black/10"
                >
                  Continue to Payment
                </button>
              </div>
            </div>
          )}

          {checkoutStep === 2 && (
            <div className="space-y-6">
              {/* Google Pay - Primary */}
              <button 
                onClick={() => setCheckoutStep(3)}
                className="w-full bg-black text-white p-6 rounded-3xl flex items-center justify-center space-x-3 hover:bg-zinc-900 transition-all shadow-xl shadow-black/20 group"
              >
                <img src="https://www.gstatic.com/images/branding/googlelogo/2x/googlelogo_light_color_92x30dp.png" alt="Google" className="h-6" />
                <span className="text-xl font-medium">Pay</span>
              </button>

              <div className="relative py-4">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                <div className="relative flex justify-center text-xs uppercase tracking-widest font-bold text-slate-400"><span className="bg-[#f5f5f7] px-4">Or pay with card</span></div>
              </div>

              <div className="apple-card p-10 bg-white shadow-xl border border-black/[0.03]">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold text-[#1d1d1f]">Credit / Debit Card</h3>
                  <div className="flex space-x-2">
                    <div className="w-10 h-6 bg-slate-100 rounded flex items-center justify-center text-[8px] font-bold text-slate-400">VISA</div>
                    <div className="w-10 h-6 bg-slate-100 rounded flex items-center justify-center text-[8px] font-bold text-slate-400">MC</div>
                  </div>
                </div>
                
                <div className="space-y-4 mb-8">
                  <div className="px-6 py-4 bg-[#f5f5f7] rounded-2xl text-slate-400 text-sm">Card Number: •••• •••• •••• 4242</div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="px-6 py-4 bg-[#f5f5f7] rounded-2xl text-slate-400 text-sm">Exp: 12/25</div>
                    <div className="px-6 py-4 bg-[#f5f5f7] rounded-2xl text-slate-400 text-sm">CVC: •••</div>
                  </div>
                </div>

                <button 
                  onClick={() => setCheckoutStep(3)}
                  className="w-full bg-[#0071e3] text-white py-5 rounded-2xl font-bold hover:bg-[#0077ed] transition-all shadow-lg shadow-blue-500/20"
                >
                  Use this card
                </button>
              </div>

              <button onClick={() => setCheckoutStep(1)} className="w-full text-slate-400 font-bold text-sm hover:text-[#1d1d1f] transition-colors">
                Back to shipping
              </button>
            </div>
          )}

          {checkoutStep === 3 && (
            <div className="apple-card p-10 bg-white shadow-xl border border-black/[0.03]">
              <h3 className="text-lg font-bold text-[#1d1d1f] mb-8">Order Summary</h3>
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-slate-500">
                  <span>StopCardiac Test Kit</span>
                  <span className="font-bold text-[#1d1d1f]">$199.00</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Shipping</span>
                  <span className="text-emerald-600 font-bold">FREE</span>
                </div>
                <div className="pt-4 border-t border-slate-100 flex justify-between">
                  <span className="font-bold text-[#1d1d1f]">Total</span>
                  <span className="text-2xl font-bold text-[#0071e3]">$199.00</span>
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-2xl mb-8 border border-blue-100">
                <div className="flex items-start space-x-3">
                  <Info className="w-5 h-5 text-[#0071e3] mt-0.5" />
                  <p className="text-xs text-[#0071e3] leading-relaxed">
                    By clicking "Place Order", you agree to our terms of service and privacy policy. Your genetic data is encrypted and never shared with third parties.
                  </p>
                </div>
              </div>

              <button 
                onClick={() => handleOrder()}
                disabled={isProcessing}
                className="w-full bg-[#0071e3] text-white py-6 rounded-2xl font-bold text-xl hover:bg-[#0077ed] transition-all shadow-xl shadow-blue-500/20 flex items-center justify-center"
              >
                {isProcessing ? (
                  <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  'Place Order'
                )}
              </button>
              
              <button onClick={() => setCheckoutStep(2)} className="w-full mt-6 text-slate-400 font-bold text-sm hover:text-[#1d1d1f] transition-colors">
                Back to payment
              </button>
            </div>
          )}
        </motion.div>

        <div className="space-y-8">
          <div className="bg-[#1d1d1f] text-white p-10 rounded-[2rem] shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl" />
            <h3 className="text-xl font-bold mb-6">What's in the kit?</h3>
            <ul className="space-y-4">
              {[
                "Sterile Buccal Swab",
                "DNA Stabilizing Tube",
                "Prepaid Return Envelope",
                "Step-by-step Instructions",
                "Unique Sample ID Barcode"
              ].map((item, i) => (
                <li key={i} className="flex items-center text-slate-400 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 mr-3" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="apple-card p-10 bg-white border border-black/[0.03]">
            <h3 className="text-lg font-bold text-[#1d1d1f] mb-6">Need help?</h3>
            <p className="text-sm text-slate-500 mb-6 leading-relaxed">
              Our support team is available 24/7 to assist you with your order or any questions about the testing process.
            </p>
            <button className="flex items-center text-[#0071e3] font-bold text-sm hover:underline">
              <MessageSquare className="w-4 h-4 mr-2" />
              Chat with an expert
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useState<UserType | null>(null);
  const [pageParams, setPageParams] = useState<any>(null);

  const navigate = (page: string, params?: any) => {
    setCurrentPage(page);
    setPageParams(params);
    window.scrollTo(0, 0);
  };

  useEffect(() => {
    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        supabase.from('profiles').select('*').eq('id', session.user.id).single().then(({ data }) => {
          if (data) setUser(data);
        });
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        supabase.from('profiles').select('*').eq('id', session.user.id).single().then(({ data }) => {
          if (data) setUser(data);
        });
      } else {
        setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    navigate('home');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <HomePage onOrder={() => navigate(user ? 'checkout' : 'auth')} onNavigate={navigate} />;
      case 'auth': return <AuthPage onAuthSuccess={(u) => { setUser(u); navigate('dashboard'); }} />;
      case 'dashboard': return user ? <Dashboard user={user} onNavigate={navigate} /> : <AuthPage onAuthSuccess={(u) => { setUser(u); navigate('dashboard'); }} />;
      case 'checkout': return user ? <CheckoutPage user={user} onOrderSuccess={() => navigate('dashboard')} /> : <AuthPage onAuthSuccess={(u) => { setUser(u); navigate('checkout'); }} />;
      case 'report': return <ReportViewer orderId={pageParams?.orderId} onNavigate={navigate} />;
      case 'how-it-works': return <HowItWorksPage />;
      case 'faq': return <FAQPage />;
      case 'doctors': return <DoctorNetworkPage />;
      case 'science': return <SciencePage onNavigate={navigate} />;
      case 'shop': return <ShopPage onOrder={() => navigate(user ? 'checkout' : 'auth')} />;
      case 'sync': return <HealthSyncPage />;
      case 'sample-report': return <DetailedReportPage />;
      case 'profile': return <ProfilePage user={user!} />;
      case 'admin': return <AdminPanel />;
      default: return <HomePage onOrder={() => navigate(user ? 'checkout' : 'auth')} onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar user={user} onLogout={handleLogout} onNavigate={navigate} />
      
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="bg-slate-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-6">
                <Heart className="h-8 w-8 text-brand-accent fill-brand-accent/20" />
                <span className="ml-2 text-2xl font-display font-bold">StopCardiac</span>
              </div>
              <p className="text-slate-400 max-w-sm leading-relaxed">
                Empowering South Asian families with genetic insights to prevent sudden cardiac events. One test, once in your life, for a lifetime of peace of mind.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-6">Platform</h4>
              <ul className="space-y-4 text-slate-400 text-sm">
                <li><button onClick={() => navigate('how-it-works')} className="hover:text-white transition-colors">How It Works</button></li>
                <li><button onClick={() => navigate('science')} className="hover:text-white transition-colors">The Science</button></li>
                <li><button onClick={() => navigate('shop')} className="hover:text-white transition-colors">Shop</button></li>
                <li><button onClick={() => navigate('sync')} className="hover:text-white transition-colors">Health Sync</button></li>
                <li><button onClick={() => navigate('doctors')} className="hover:text-white transition-colors">Doctor Network</button></li>
                <li><button onClick={() => navigate('faq')} className="hover:text-white transition-colors">FAQ</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6">Legal</h4>
              <ul className="space-y-4 text-slate-400 text-sm">
                <li><button className="hover:text-white transition-colors">Privacy Policy</button></li>
                <li><button className="hover:text-white transition-colors">Terms of Service</button></li>
                <li><button className="hover:text-white transition-colors">HIPAA Compliance</button></li>
                <li><button className="hover:text-white transition-colors">Cookie Policy</button></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center text-slate-500 text-xs font-medium uppercase tracking-widest">
            <p>© 2026 StopCardiac. All rights reserved.</p>
            <div className="mt-4 md:mt-0 flex space-x-6">
              <span>Made with care for healthy hearts</span>
            </div>
          </div>
        </div>
      </footer>

      <Chatbot />
    </div>
  );
}

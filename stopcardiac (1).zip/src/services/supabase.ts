import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn('Supabase credentials missing. The app will not function correctly until VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set in environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database Types (for reference and safety)
export type UserProfile = {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  created_at: string;
};

export type Order = {
  id: string;
  user_id: string;
  status: 'ordered' | 'sample_sent' | 'sample_received' | 'processing' | 'report_ready';
  shipping_address: string;
  created_at: string;
};

export type Report = {
  id: string;
  order_id: string;
  result: 'normal' | 'vus' | 'likely_pathogenic' | 'pathogenic';
  explanation: string;
  physician_name: string;
  physician_license: string;
  created_at: string;
};

import { GoogleGenAI, Modality, LiveServerMessage } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function connectLiveAudio(callbacks: {
  onopen: () => void;
  onmessage: (message: LiveServerMessage) => void;
  onerror: (error: any) => void;
  onclose: () => void;
}) {
  return ai.live.connect({
    model: "gemini-2.5-flash-native-audio-preview-09-2025",
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
      },
      systemInstruction: "You are a helpful assistant for StopCardiac, a genetic testing service for the MYBPC3 gene mutation. You help users understand the testing process, their results, and general heart health. Use plain English and be reassuring. If asked medical advice, always suggest consulting a licensed cardiologist. You are in a real-time voice conversation.",
    },
  });
}

export async function getChatResponse(message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) {
  const model = "gemini-3-flash-preview";
  const chat = ai.chats.create({
    model,
    config: {
      systemInstruction: "You are a helpful assistant for StopCardiac, a genetic testing service for the MYBPC3 gene mutation. You help users understand the testing process, their results, and general heart health. Use plain English and be reassuring. If asked medical advice, always suggest consulting a licensed cardiologist.",
    },
  });

  // Since we can't easily pass history to ai.chats.create in this SDK version without a bit more work, 
  // we'll just send the message for now or implement a simple history wrapper if needed.
  // Actually, sendMessage handles the turn.
  
  const response = await chat.sendMessage({ message });
  return response.text;
}

export async function interpretReport(result: string, explanation: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Please provide a simple, reassuring, plain-English summary of this genetic test result:
    Result: ${result}
    Technical Explanation: ${explanation}
    
    Focus on what the user should do next and how to stay healthy.`,
  });
  return response.text;
}

export async function evaluateRisk(answers: { question: string, answer: string }[]) {
  const model = "gemini-3-flash-preview";
  const prompt = `Based on the following user information, provide a brief (2-3 sentences) assessment of whether they should consider genetic testing for the MYBPC3 mutation. 
  Be professional, empathetic, and always include a disclaimer that this is not medical advice.
  
  User Information:
  ${answers.map(a => `- ${a.question}: ${a.answer}`).join('\n')}
  
  If the user has family history or symptoms, strongly suggest the test. If not, suggest it as a proactive measure for South Asians.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
  });
  return response.text;
}

export async function generateTechnicalExplanation(result: string) {
  const model = "gemini-3-flash-preview";
  const prompt = `Write a professional, technical medical explanation for a genetic test result of "${result}" regarding the MYBPC3 25bp deletion mutation. 
  The explanation should be suitable for a medical report but clear enough for a doctor to discuss with a patient. 
  Include information about the mutation's prevalence in South Asians and its association with late-onset hypertrophic cardiomyopathy.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
  });
  return response.text;
}

# Lovable Setup Guide

This project is optimized for deployment on **Lovable**, **Netlify**, or **Vercel**. Since it uses **Supabase** as a serverless backend, you can deploy it as a static Single Page Application (SPA).

## 1. Supabase Backend Setup

Before the app will function, you must set up your Supabase project:

1.  **Create a new project** at [supabase.com](https://supabase.com).
2.  **Run the Database Schema**: Open the **SQL Editor** in your Supabase dashboard and paste the contents of the `Database Schema` section from `DEPLOYMENT.md`.
3.  **Enable Authentication**:
    *   Go to **Authentication > Providers**.
    *   Ensure **Email** provider is enabled.
    *   Disable "Confirm Email" for testing, or configure your SMTP settings.

## 2. Environment Variables

In your Lovable (or deployment platform) settings, add the following environment variables:

| Variable | Description |
| :--- | :--- |
| `VITE_SUPABASE_URL` | Your Supabase Project URL (found in Project Settings > API) |
| `VITE_SUPABASE_ANON_KEY` | Your Supabase Anon Key (found in Project Settings > API) |
| `GEMINI_API_KEY` | Your Google Gemini API Key (for the AI Assistant) |

## 3. Local Development

To run the project locally:

1.  **Install dependencies**: `npm install`
2.  **Create a `.env` file**: Copy `.env.example` to `.env` and fill in your keys.
3.  **Start the dev server**: `npm run dev`

## 4. Deployment

*   **Build Command**: `npm run build`
*   **Output Directory**: `dist`
*   **SPA Routing**: If using Netlify, the `netlify.toml` is already included. For other platforms, ensure all routes are redirected to `index.html`.

## 5. Lovable Specifics

Lovable can import this project directly from a GitHub repository or via a zip upload. 
*   Ensure all files in this export are included.
*   The project uses **Vite** and **Tailwind CSS v4**, which are standard and supported.
